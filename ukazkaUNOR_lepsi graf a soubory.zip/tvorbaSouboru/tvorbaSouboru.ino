
#include <SPI.h>
#include <SD.h>

const int chipSelectSD = 6;
File zaznamMereni;

String celyNazev;
String mereniText = "karta_";
String priponaText = ".CSV";
String cisloMereni;


void setup() {

  Serial.begin(115200);



  Serial.print("SD: inicializace");
  if (!SD.begin(chipSelectSD)) {
    Serial.println(" neuspesna");
  } else {
    Serial.println(" uspesna");
  }

  for(int i = 0;i < 100;i++){
    if(i < 10){cisloMereni = "0" + String(i);}
    else{cisloMereni = String(i);}
    celyNazev = mereniText + cisloMereni + priponaText;
    //sprintf(nazevSouboru, "MERENI %d3.csv", i);
    zaznamMereni = SD.open(celyNazev, FILE_WRITE);
    zaznamMereni.close();
    celyNazev = "";
    cisloMereni = "";
    Serial.println(i);
  }
}

void loop() {

}
