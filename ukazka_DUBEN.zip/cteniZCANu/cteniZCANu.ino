// CAN Receive Example
//

#include <mcp_can.h>
#include <SPI.h>

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];
char msgString[128];  

#define CAN0_INT 2  
MCP_CAN CAN0(10);   

//zkouska posilani zpravy
byte testovaciZprava0[8] = {0x00, 0x00, 0b00000111, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
unsigned long int ZZ_CTRL= 0x15F773F5;
unsigned long int ZZ_SET = 0x15F774F5;
unsigned long int ZZ_INF1= 0x15F771F5;
unsigned long int ZZ_INF2= 0x15F772F5;

//byte CANTxOK = 0xFF;
//byte data[8] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07};
/*
  byte sndStat = CAN0.sendMsgBuf(0x100, 0, 8, data);
  if(sndStat == CAN_OK){
    Serial.println("Message Sent Successfully!");
  } else {
    Serial.println("Error Sending Message...");
  }
*/

void setup() {
  Serial.begin(115200);

  if (CAN0.begin(MCP_ANY, CAN_500KBPS, MCP_16MHZ) == CAN_OK)
    Serial.println("CAN: MCP2515 se bavi");
  else
    Serial.println("CAN: MCP2515 se nebavi");

  CAN0.setMode(MCP_NORMAL);  

  pinMode(CAN0_INT, INPUT);  

  Serial.println("CAN: MCP2515 zkouska posilani a prijmu zprav");

  byte CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);
  if(CANTxOK == CAN_OK){
    Serial.println("CAN: zprava uspesne poslana");
  } else {
    Serial.println("CAN: zprava nedorazila");
  }
}

void loop() {
  if (!digitalRead(CAN0_INT))  
  {
    CAN0.readMsgBuf(&rxId, &len, rxBuf);  
    rxId -= 0x80000000;
    if (rxId == 0x15F772F5) {
      sprintf(msgString, "Standard ID: 0x%.3lX       DLC: %1d  Data:", rxId, len);//z ukazky v knihovne modfikovane pro sobni ucely
      Serial.print(msgString);

      for (byte i = 0; i < len; i++) {
        sprintf(msgString, " 0x%.2X", rxBuf[i]);
        Serial.print(msgString);
      }

      Serial.println();
    }
  }
}

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/
