
#include <mcp_can.h>
#include <SPI.h>
#include <SoftwareSerial.h>
#include <SD.h>

const int chipSelectSD = 6;
File dataFile;
unsigned long int cycleCount = 0;
#define rx 3
#define tx 4

unsigned short int calcX = 0;
unsigned short int calcY = 0;

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];
char msgString[128];

int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };


SoftwareSerial kom(rx, tx);
MCP_CAN CAN0(10);

void printRxCAN();
void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cislo);

void charCislaNaHexZpravu(char znak);
void vypisCislice(unsigned int cislo);
void kalibraceDotyku();

/////////////////////////////////////////////////////////////////////////
/*
implementace prace s GUI prostrednictvim dotyku a prepinani ulozenych obrazku v displeji 
*/

int dotykRychlejsi(); //prikazy 0x72 a 0x73
void prepnutiObrazku(short unsigned int volba);
const byte prikazObraz = 0x70;
short int predeslyObr = 0;

void GUIuvodniMenu();
void GUImanual();
void GUIkontrola();
void GUIkalibrace();
void GUImereni();
void GUImereniH();
void GUImereniS();
void GUImereniJ();
void GUIgraf();

//funkce a hodnoty pro kresbu a praci s grafem
//
unsigned short int recordID = 0;
const byte BLACK[2] = { 0x00, 0x00 };
const byte WHITE[2] = { 0xFF, 0xFF };
const byte GREEN[2] = { 0x07, 0x00 };
const byte RED[2] = { 0xF8, 0x00 };

//OSA X
byte osaX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
byte osaX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
byte osaX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
byte osaX_YE[2] = { osaX_YO[0], osaX_YO[1] };
//OSA Y
byte osaY_XO[2] = { 0x00, 0xF0 };  //200 pix na sirku, veprostred osy x
byte osaY_YO[2] = { osaX_YO[0], osaX_YO[1] };
byte osaY_XE[2] = { osaY_XO[0], osaY_XO[1] };
byte osaY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

//"stredova" osa
//byte stred_XO[2] = {osaX_XO[0], osaX_XO[1]};
//byte stred_YO[2] = { 0x00, 0xC8 };  //200 pix na vysku
//byte stred_XE[2] = {osaX_XE[0], osaX_XE[1]};
//byte stred_YE[2] = {stred_YO[0], stred_YO[1]};  //50 pix na vysku

const short unsigned int velikostPole = 240;
short int Yhodnoty[velikostPole];  // y = 200 * (sin(x) + 1 )

/*
volba = 1 -> CERNA/BILA
volba = 2 -> CERVENA/BILA
volba = 3 -> ZELENA/BILA
*/

void nastavBarvu(short unsigned int volba);
void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba);
void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]);
void mrizka();
/////////////////////////////////////////////////////////////////////////


void setup() {
  Serial.begin(19200);
  kom.begin(9600);
  delay(200);


  // nastaveni LEDek
  pinMode(A1, OUTPUT);
  pinMode(A2, OUTPUT);
  pinMode(A3, OUTPUT);
  pinMode(A4, OUTPUT);
  pinMode(A5, OUTPUT);

  //for(int i = 0; i <= 8;i++){prepnutiObrazku(i);delay(1000);}
  delay(1500);
  digitalWrite(A5, HIGH);
  GUIuvodniMenu();
}

int kZahozeni = 0;

void loop() {
  kZahozeni = dotykRychlejsi();
}


void GUIuvodniMenu() {
  prepnutiObrazku(1);
  while (1) {
    kZahozeni = dotykRychlejsi();
    //if(souradnice(110,210,330,380)){GUIkontrola();}
    //else if(souradnice(270,370,330,380)){GUImereniH();}
    //else if(souradnice(430,530,330,380)){GUIkalibrace();}
    if(kZahozeni){
    if (calcY > 180 && calcY < 250) {
      if (calcX > 110 && calcX < 210) { GUImereniH(); }
      if (calcX > 270 && calcX < 380) { GUImereniS(); }
      if (calcX > 430 && calcX < 540) { GUImereniJ(); }
    } else if (calcY > 260 && calcY < 330) {
      if (calcX > 110 && calcX < 210) { GUIkontrola(); }
      if (calcX > 270 && calcX < 380) { GUImanual(); }
      if (calcX > 430 && calcX < 540) { GUIkalibrace(); }
    }}
  }
}
void GUImanual() {
  prepnutiObrazku(2);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX > 550 && calcY > 420) { GUIuvodniMenu(); }}
  }
}
void GUIkontrola() {
  prepnutiObrazku(4);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX > 550 && calcY > 420) { GUIuvodniMenu(); }}
  }
}
void GUIkalibrace() {
  prepnutiObrazku(3);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX > 550 && calcY > 420) { GUIuvodniMenu(); }}
  }
}

void GUImereniH() {
  predeslyObr = 5;
  prepnutiObrazku(5);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX < 300 && calcY > 420) { // <- Z ->
      if (calcX < 90) { Serial.println("Doleva"); }
      else if (calcX > 90 && calcX < 210) { Serial.println("Zaznam"); }
      else if (calcX > 211 && calcX < 300) { Serial.println("Doprava"); }
    }
    if (calcX > 315 && calcX < 530 && calcY > 380) {
      if (calcX > 315 && calcX < 425) {//sloupec Auto
        if(calcY > 380 && calcY < 430){Serial.println("Auto Start");}
        else if(calcY > 431){Serial.println("Auto Stop");}
      }
      else if (calcX > 426 && calcX < 530) {//sloupec SD
        if(calcY > 380 && calcY < 430){Serial.println("SD Ulozit");}
        else if(calcY > 431){Serial.println("SD Zahodit");}
      }
    }    
    else if (calcX > 530) {
       if (calcY > 70 && calcY < 120) {GUIuvodniMenu();}
       else if (calcY > 230 && calcY < 280) {GUIgraf();}
       
    }}
  }
}
void GUImereniS() {
  predeslyObr = 6;
  prepnutiObrazku(6);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX < 300 && calcY > 420) { // <- Z ->
      if (calcX < 90) { Serial.println("Doleva"); }
      else if (calcX > 90 && calcX < 210) { Serial.println("Zaznam"); }
      else if (calcX > 211 && calcX < 300) { Serial.println("Doprava"); }
    }
    if (calcX > 315 && calcX < 530 && calcY > 380) {
      if (calcX > 315 && calcX < 425) {//sloupec Auto
        if(calcY > 380 && calcY < 430){Serial.println("Auto Start");}
        else if(calcY > 431){Serial.println("Auto Stop");}
      }
      else if (calcX > 426 && calcX < 530) {//sloupec SD
        if(calcY > 380 && calcY < 430){Serial.println("SD Ulozit");}
        else if(calcY > 431){Serial.println("SD Zahodit");}
      }
    }    
    else if (calcX > 530) {
       if (calcY > 70 && calcY < 120) {GUIuvodniMenu();}
       else if (calcY > 230 && calcY < 280) {GUIgraf();}
       
    }}
  }
}
void GUImereniJ() {
  predeslyObr = 7;
  prepnutiObrazku(7);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX < 300 && calcY > 420) { // <- Z ->
      if (calcX < 90) { Serial.println("Doleva"); }
      else if (calcX > 90 && calcX < 210) { Serial.println("Zaznam"); }
      else if (calcX > 211 && calcX < 300) { Serial.println("Doprava"); }
    }
    if (calcX > 315 && calcX < 530 && calcY > 380) {
      if (calcX > 315 && calcX < 425) {//sloupec Auto
        if(calcY > 380 && calcY < 430){Serial.println("Auto Start");}
        else if(calcY > 431){Serial.println("Auto Stop");}
      }
      else if (calcX > 426 && calcX < 530) {//sloupec SD
        if(calcY > 380 && calcY < 430){Serial.println("SD Ulozit");}
        else if(calcY > 431){Serial.println("SD Zahodit");}
      }
    }    
    else if (calcX > 530) {
       if (calcY > 70 && calcY < 120) {GUIuvodniMenu();}
       else if (calcY > 230 && calcY < 280) {GUIgraf();}
       
    }}
  }
}

void GUIgraf() {
  prepnutiObrazku(8);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if(kZahozeni){
    if (calcX > 550 && calcY > 420) {
      switch (predeslyObr) {
        case 5:
          GUImereniH();
          break;//technicky tam nemusi byt
        case 6:
          GUImereniS();
          break;
        case 7:
          GUImereniJ();
          break;
        default:
          GUIuvodniMenu();
      }
    }}
  }
}


void prepnutiObrazku(short unsigned int volba) {

  posliZacatek();
  posli1Byte(prikazObraz);
  posli1Byte(volba);
  posliKonec();
  //calcX = 0; calcY = 0;
}

int dotykRychlejsi() {  //0 ... ticho, 1 ... uspech, 2 ... spatna zprava, 3 ... chybny vypocet, 4 ... spatne nactena data
  //delay(10);
  Serial.print(calcX);Serial.print(", ");Serial.println(calcY);
  //Serial.print("");
  calcX = 0;
  calcY = 0;
  byte prevzatyByte0 = 0x00;
  unsigned short int osetreniDvojitehoZacatku = 0;
  //byte prevzatyByte1 = 0x00;
  //byte poziceX[2]={0x00,0x00};
  //byte poziceY[2]={0x00,0x00};
  byte buffer[20];
  for (int i = 0; i < 20; i++) { buffer[i] = 0xFF; }
  //calcX a calcY

  for (int i = 0; i < 20; i++) {  //cteci smycka
    prevzatyByte0 = kom.read();
    if (prevzatyByte0 == 0xFF) { continue; }
    if (prevzatyByte0 == 0x3C) {
      buffer[i] = prevzatyByte0;
      break;
    } else {
      buffer[i] = prevzatyByte0;
    }
  }

  //if((buffer[i+1] == 0x72) || (buffer[i+1] == 0x73))
  //Serial.println("=============");
 for (int i = 0; i < 20; i++) {  //vypisovaci smycka
    if (buffer[i] == 0xFF) { continue; }
    //else if(buffer[i] == 0x3C){break;}
    else {
      Serial.println(buffer[i], HEX);
    }

  }
  //Serial.println("=============");


  for (int i = 0; i < 20; i++) {
    if (buffer[i] == 0xAA) { osetreniDvojitehoZacatku += 1; }
  }  //osetreniDvojitehoZacatku

  if (osetreniDvojitehoZacatku > 1) {
    Serial.println("Displej blbne.");
    return 2;
  } else if (osetreniDvojitehoZacatku == 0) { /*Serial.println("Je ticho.");*/
    calcX = 0;
    calcY = 0;
    return 0;
  }

  for (int i = 0; i < 20; i++) {  //vypocetni smycka
    if (buffer[i] == 0xAA) {
      if ((buffer[i + 1] == 0x72) || (buffer[i + 1] == 0x73)) {
        Serial.print("Souradnice surove: ");Serial.print(buffer[i + 2]);Serial.print(", ");Serial.print(buffer[i + 3]);Serial.print(", ");Serial.print(buffer[i + 4]);Serial.print(", ");
        Serial.println(buffer[i + 5]);
        //if ((buffer[i + 2] > 2) || (buffer[i + 4] > 3)) {Serial.println("Spatne nactena data");return 4;}
        calcX = 16 * 16 * buffer[i + 2] + buffer[i + 3];
        calcY = 16 * 16 * buffer[i + 4] + buffer[i + 5];
        Serial.print("Souradnice: ");Serial.print(calcX);Serial.print(", ");Serial.println(calcY);
        if ((calcX > 640) || (calcY > 480)) {
          Serial.println("Chybny vypocet");
          return 3;
        }
        Serial.print("Souradnice zpracovane: ");
        Serial.print(calcX);
        Serial.print(", ");
        Serial.println(calcY);
        Serial.println("=============");
        return 1;  //uspech
      }
    }
  }
}


void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]) {

  int odsazeni = 200;
  byte pomocY[2] = { 0x00, 0x96 };
  byte pomocKrok[2] = { 0x00, krok };

  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart);
  posli1Byte(krok);
  posli2Byte(osaX_YO);
  for (int i = 0; i < 120; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();

  byte Xstart2[2] = { Xstart[0], Xstart[1] + 240 };
  ////////////////////////////
  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart2);
  posli1Byte(krok);

  if (poleHodnot[120] < 255) {
    posli1Byte(0x00);
    posli1Byte(poleHodnot[120]);
  } else {
    posli1Byte(0x01);
    poleHodnot[120] -= 255;
    posli1Byte(poleHodnot[120]);
    poleHodnot[120] += 255;
  }


  //posli2Byte(osaX_YO);
  for (int i = 120; i < 240; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();
}

void kalibraceDotyku() {
  posliZacatek();
  posli1Byte(0xE4);
  posli1Byte(0x55);
  posliZacatek();
  posli1Byte(0x5A);
  posli1Byte(0xA5);
  posliKonec();
}

void nastavBarvu(short unsigned int volba) {
  /*
 volba = 1 -> CERNA/BILA
 volba = 2 -> CERVENA/BILA
 volba = 3 -> ZELENA/BILA
 */

  posliZacatek();

  switch (volba) {
    case 1:  //mezera
      posli1Byte(0x40);
      posli2Byte(BLACK);
      posli2Byte(WHITE);
      break;
    case 2:  //mezera
      posli1Byte(0x40);
      posli2Byte(RED);
      posli2Byte(WHITE);
      break;
    case 3:  //mezera
      posli1Byte(0x40);
      posli2Byte(GREEN);
      posli2Byte(WHITE);
      break;
    default:
      digitalWrite(A1, HIGH);
      break;
  }

  posliKonec();
}

void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba) {
  posliZacatek();
  posli1Byte(0x56);
  posli2Byte(Xstart);
  posli2Byte(Ystart);
  posli2Byte(Xkonec);
  posli2Byte(Ykonec);
  posliKonec();

  if (volba == 1) {  //tlustsi osa Y
    Xstart[1] += 1;
    Xkonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Xstart[1] -= 1;
    Xkonec[1] -= 1;
  }

  if (volba == 2) {  //tlustsi osa X
    Ystart[1] += 1;
    Ykonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Ystart[1] -= 1;
    Ykonec[1] -= 1;
  }
}

void mrizka() {
  int volbaX = 0;  //2
  int volbaY = 0;  //1

  //OKRAJ X
  byte okrX_XO[2] = { 0x00, 0x00 };
  byte okrX_YO[2] = { 0x00, 0x00 };  //odsazeni 400 pix
  byte okrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte okrX_YE[2] = { okrX_YO[0], okrX_YO[1] };
  //OKRAJ Y
  byte okrY_XO[2] = { 0x00, 0x00 };
  byte okrY_YO[2] = { okrX_YO[0], okrX_YO[1] };
  byte okrY_XE[2] = { okrY_XO[0], okrY_XO[1] };
  byte okrY_YE[2] = { 0x01, 0x90 };

  //MRIZKA X
  byte mrX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
  byte mrX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
  byte mrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte mrX_YE[2] = { mrX_YO[0], mrX_YO[1] };
  //MRIZKA Y
  byte mrY_XO[2] = { 0x00, 0x00 };  //200 pix na sirku, veprostred osy x
  byte mrY_YO[2] = { mrX_YO[0], mrX_YO[1] };
  byte mrY_XE[2] = { mrY_XO[0], mrY_XO[1] };
  byte mrY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

  short unsigned int odsazeniX = 0;
  short unsigned int odsazeniY = 0;

  nastavBarvu(1);
  nakresliUsecku(okrY_XO, okrY_YO, okrY_XE, okrY_YE, 1);
  nakresliUsecku(okrX_XO, okrX_YO, okrX_XE, okrX_YE, 2);

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniX += 60;
    if (odsazeniX < 255) {
      mrY_XO[0] = 0x00;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
    } else {
      odsazeniX -= 255;
      mrY_XO[0] = 0x01;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
      odsazeniX += 255;
      if (i == 8) {
        nastavBarvu(1);
        volbaY = 1;
      }
    }
    nakresliUsecku(mrY_XO, mrY_YO, mrY_XE, mrY_YE, volbaY);
  }

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniY += 50;
    Serial.print("Y: ");
    Serial.print(odsazeniY);
    if (odsazeniY < 255) {
      mrX_YO[0] = 0x00;
      mrX_YO[1] = 50 * i;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    } else {
      odsazeniY -= 255;
      mrX_YO[0] = 0x01;
      mrX_YO[1] = odsazeniY;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      odsazeniY += 255;
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    }
  }
  //mrX_YE[0] = mrX_YO[0]; mrX_YE[1] = mrX_YO[1];
  //nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
  nastavBarvu(3);
}


void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}

void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}
void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}
void posliPrevedeneCislo(unsigned int cislo) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cislo, bufferProCislo, 10);
  if ((cislo < 100) && (cislo >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cislo < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}

void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}

void vypisCislice(unsigned int cislo) {  //3mistny cislo


  byte poziceXNum[] = { 0x00, 0xFF };
  byte poziceYNum[] = { 0x00, 0xFF };
  byte zluta[] = { 0xFC, 0x00 };
  byte modra[] = { 0x00, 0x1F };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(poziceXNum);
  posli2Byte(poziceYNum);
  posli1Byte(0x00);  //00
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(zluta);
  posli2Byte(modra);
  posli1Byte(0x00);
  posliPrevedeneCislo(cislo);

  posliKonec();
}
