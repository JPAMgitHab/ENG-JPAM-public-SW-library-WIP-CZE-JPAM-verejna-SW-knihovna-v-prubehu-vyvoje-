
#include <SPI.h>
#include <SD.h>

const int chipSelectSD = 6;
short unsigned int hodnotaSoubor = 0;



/*
//tvorba souboru
File zaznamMereni;
String celyNazev;
String mereniText = "karta_";
String priponaText = ".CSV";
String cisloMereni;
*/

//cteni ze souboru
File souborProPrecteni;
//String celyRadek;
String konfiguracniSoubor = "CONFIG.TXT";

char prectenyPrikaz[7] = "aaaaaaa";
char znak;

const char prikazPWM[4] = "PWMT";                               //radek ... PPPP_HH; P = prikaz, H = hodnota od 00 po 99
short unsigned int najdiPrikaz(char radek[7], char prikaz[4]);  //vraci ,,zakodovanou hodnotu"
//VYPIS PROGRAMU SE SD KARTOU 
/*
SD: inicializace uspesna
USPECH NALEZU KONFIGURACNIHO SOUBORU
--------------------
PWMT_50
50
DOSTAL JSEM HODNOTU: 50
HODNOTA + 10 = 60
--------------------
PWMT_11
11
DOSTAL JSEM HODNOTU: 11
HODNOTA + 10 = 21
--------------------
PWMT_@0
100
NEBYLA ZADANA CISELNA HODNOTA
--------------------
PWMT_1i
100
NEBYLA ZADANA CISELNA HODNOTA
--------------------
XWMT_50
200
NEBYL NALEZEN PRIKAZ
--------------------
PXMT_50
200
NEBYL NALEZEN PRIKAZ
--------------------
PWXT_50
200
NEBYL NALEZEN PRIKAZ
--------------------
PWMX_50
200
NEBYL NALEZEN PRIKAZ
--------------------
XXXX_50
200
NEBYL NALEZEN PRIKAZ
--------------------
*/
void setup() {

  Serial.begin(115200);



  Serial.print("SD: inicializace");
  if (!SD.begin(chipSelectSD)) {
    Serial.println(" neuspesna");
  } else {
    Serial.println(" uspesna");
  }

  //cteni souboru
  souborProPrecteni = SD.open(konfiguracniSoubor);

  if (souborProPrecteni) {
    Serial.println("USPECH NALEZU KONFIGURACNIHO SOUBORU");
    Serial.println("--------------------");
    for (int i = 0; i < 9; i++) {  //9 radku
      for (int i = 0; i < sizeof(prectenyPrikaz); i++) {
        znak = souborProPrecteni.read();
        if (znak == '\n') {
          znak = souborProPrecteni.read();
          i -= 1;
        }  //to zahod, to se nepocita, zkus to jeste jednou
        prectenyPrikaz[i] = znak;
      }

      for (int i = 0; i < sizeof(prectenyPrikaz); i++) {
        Serial.print(prectenyPrikaz[i]);
      }
      Serial.println();

      hodnotaSoubor = najdiPrikaz(prectenyPrikaz, prikazPWM);
      Serial.println(hodnotaSoubor);

      if (hodnotaSoubor == 100) { Serial.println("NEBYLA ZADANA CISELNA HODNOTA"); }
      else if (hodnotaSoubor == 200) { Serial.println("NEBYL NALEZEN PRIKAZ");} 
      else {
        Serial.print("DOSTAL JSEM HODNOTU: "); Serial.println(hodnotaSoubor);
        Serial.print("HODNOTA + 10 = "); Serial.println(hodnotaSoubor + 10);
        
      }
      Serial.println("--------------------");
    }
  } else {
    Serial.println("NEUSPECH NALEZU KONFIGURACNIHO SOUBORU");
  }
}

void loop() {
}

short unsigned int najdiPrikaz(char radek[7], char prikaz[4]) {
  bool jeTamPrikaz = 1;
  short unsigned int predanaHodnota = 0;
  for (int i = 0; i < 4; i++) {
    if (radek[i] != prikaz[i]) { jeTamPrikaz = 0; }  //porovnej prvni 4 znaky
  }
  //https://web.alfredstate.edu/faculty/weimandn/miscellaneous/ascii/ascii_index.html
  if ((radek[5] < 48) || (radek[5] > 57) || (radek[6] < 48) || (radek[6] > 57)) { return 100; }  //chybova hodnota, nejedna se o ASCII znak cisla
  if (jeTamPrikaz) {predanaHodnota = 10 * (radek[5] - 48) + (radek[6] - 48);} 
  else{return 200;}  //nebyl nalezen prikaz

  return predanaHodnota;
}
