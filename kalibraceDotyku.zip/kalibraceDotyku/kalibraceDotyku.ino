
#include <mcp_can.h>
#include <SPI.h>
#include <SoftwareSerial.h>
#include <SD.h>

const int chipSelectSD = 6;
File dataFile;
unsigned long int cycleCount = 0;
#define rx 3
#define tx 4

int calcX = 0;
int calcY = 0;

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];
char msgString[128];

int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };


SoftwareSerial kom(rx, tx);
MCP_CAN CAN0(10);

void printRxCAN();
void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cislo);

int debugDotyk(bool volba);  //FALSE ... 0X72, TRUE ... OX73
void charCislaNaHexZpravu(char znak);
void vypisCislice(unsigned int cislo);
void kalibraceDotyku();
int kalibraceDotykuRx();
/////////////////////////////////////////////////////////////////////////
/*
-plnohodnotna implementace kalibrace dotyku se zpravou shody
skutecne Rx hlasky a jeji nominalni podoby.
*/

int vysledek = 0;
//funkce a hodnoty pro kresbu a praci s grafem
//
unsigned short int recordID = 0;
const byte BLACK[2] = { 0x00, 0x00 };
const byte WHITE[2] = { 0xFF, 0xFF };
const byte GREEN[2] = { 0x07, 0x00 };
const byte RED[2] = { 0xF8, 0x00 };

//OSA X
byte osaX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
byte osaX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
byte osaX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
byte osaX_YE[2] = { osaX_YO[0], osaX_YO[1] };
//OSA Y
byte osaY_XO[2] = { 0x00, 0xF0 };  //200 pix na sirku, veprostred osy x
byte osaY_YO[2] = { osaX_YO[0], osaX_YO[1] };
byte osaY_XE[2] = { osaY_XO[0], osaY_XO[1] };
byte osaY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

//"stredova" osa
//byte stred_XO[2] = {osaX_XO[0], osaX_XO[1]};
//byte stred_YO[2] = { 0x00, 0xC8 };  //200 pix na vysku
//byte stred_XE[2] = {osaX_XE[0], osaX_XE[1]};
//byte stred_YE[2] = {stred_YO[0], stred_YO[1]};  //50 pix na vysku

const short unsigned int velikostPole = 240;
short int Yhodnoty[velikostPole];  // y = 200 * (sin(x) + 1 )

/*
volba = 1 -> CERNA/BILA
volba = 2 -> CERVENA/BILA
volba = 3 -> ZELENA/BILA
*/

void nastavBarvu(short unsigned int volba);
void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba);
void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]);
void mrizka();
/////////////////////////////////////////////////////////////////////////


void setup() {
  Serial.begin(115200);
  kom.begin(9600);
  delay(200);


  // nastaveni LEDek
  pinMode(A1, OUTPUT);
  pinMode(A2, OUTPUT);
  pinMode(A3, OUTPUT);
  pinMode(A4, OUTPUT);
  pinMode(A5, OUTPUT);

  //kalibrace


  digitalWrite(A1, HIGH);

  kalibraceDotyku();
  
  while(1){//nekdy se cteni zpetne zpravy protahne, kdyz displej blbne
    vysledek = kalibraceDotykuRx();
    if(vysledek > 0 ){//potom musim cist rozsekanou zpravu, bohuzel
      vysledek += kalibraceDotykuRx();
      if(vysledek == 8){Serial.println("USPECH");break;}
    }
  }

}

void loop() {
}

int kalibraceDotykuRx() {
  unsigned short int shoda = 0;
  //unsigned short int posuvnik = 0;

  byte prevzatyByte0 = 0x00;

  byte buffer[20];
  for (int i = 0; i < 20; i++) { buffer[i] = 0xFF; }


  for (int i = 0; i < 20; i++) {  //cteci smycka
    prevzatyByte0 = kom.read();
    if (prevzatyByte0 == 0xFF) { continue; }
    /*if (prevzatyByte0 == 0x3C) {
      buffer[i] = prevzatyByte0;
      break;
    }*/ 
    else {
      buffer[i] = prevzatyByte0;
    }
  }

  //const byte kalibraceRx[8] = { 0xAA, 0xE4, 0x4F, 0x4B, 0xCC, 0x33, 0xC3, 0x3C };
  for (int i = 0; i < 20; i++) {//smycka porovnani
    switch (buffer[i]) {
      case 0xAA:
        shoda += 1;
        break;
      case 0xE4:
        shoda += 1;
        break;
      case 0x4F:
        shoda += 1;
        break;
      case 0x4B:
        shoda += 1;
        break;  
      case 0xCC:
        shoda += 1;
        break;
      case 0x33:
        shoda += 1;
        break;
      case 0xC3:
        shoda += 1;
        break;
      case 0x3C:
        shoda += 1;
        break;          
      default:
        break; 
    }
  }

  if (shoda > 0) {
    Serial.print("Shoda skutecne zpravy s idealni je: ");
    Serial.print(shoda);
    Serial.println(" znaku");
  }

  //Serial.println("=============");
  for (int i = 0; i < 20; i++) {  //vypisovaci smycka
    if (buffer[i] == 0xFF) {
      continue;
    } else if (buffer[i] == 0x3C) {
      Serial.println(buffer[i], HEX); Serial.println("=============");
      break;
    } else {
      Serial.println(buffer[i], HEX);
    }
  }
  //Serial.println("=============");

  return shoda;
}


void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]) {

  int odsazeni = 200;
  byte pomocY[2] = { 0x00, 0x96 };
  byte pomocKrok[2] = { 0x00, krok };

  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart);
  posli1Byte(krok);
  posli2Byte(osaX_YO);
  for (int i = 0; i < 120; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();

  byte Xstart2[2] = { Xstart[0], Xstart[1] + 240 };
  ////////////////////////////
  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart2);
  posli1Byte(krok);

  if (poleHodnot[120] < 255) {
    posli1Byte(0x00);
    posli1Byte(poleHodnot[120]);
  } else {
    posli1Byte(0x01);
    poleHodnot[120] -= 255;
    posli1Byte(poleHodnot[120]);
    poleHodnot[120] += 255;
  }


  //posli2Byte(osaX_YO);
  for (int i = 120; i < 240; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();
}

void kalibraceDotyku() {
  posliZacatek();
  posli1Byte(0xE4);
  posli1Byte(0x55);
  posliZacatek();
  posli1Byte(0x5A);
  posli1Byte(0xA5);
  posliKonec();
}

void nastavBarvu(short unsigned int volba) {
  /*
 volba = 1 -> CERNA/BILA
 volba = 2 -> CERVENA/BILA
 volba = 3 -> ZELENA/BILA
 */

  posliZacatek();

  switch (volba) {
    case 1:  //mezera
      posli1Byte(0x40);
      posli2Byte(BLACK);
      posli2Byte(WHITE);
      break;
    case 2:  //mezera
      posli1Byte(0x40);
      posli2Byte(RED);
      posli2Byte(WHITE);
      break;
    case 3:  //mezera
      posli1Byte(0x40);
      posli2Byte(GREEN);
      posli2Byte(WHITE);
      break;
    default:
      digitalWrite(A1, HIGH);
      break;
  }

  posliKonec();
}

void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba) {
  posliZacatek();
  posli1Byte(0x56);
  posli2Byte(Xstart);
  posli2Byte(Ystart);
  posli2Byte(Xkonec);
  posli2Byte(Ykonec);
  posliKonec();

  if (volba == 1) {  //tlustsi osa Y
    Xstart[1] += 1;
    Xkonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Xstart[1] -= 1;
    Xkonec[1] -= 1;
  }

  if (volba == 2) {  //tlustsi osa X
    Ystart[1] += 1;
    Ykonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Ystart[1] -= 1;
    Ykonec[1] -= 1;
  }
}

void mrizka() {
  int volbaX = 0;  //2
  int volbaY = 0;  //1

  //OKRAJ X
  byte okrX_XO[2] = { 0x00, 0x00 };
  byte okrX_YO[2] = { 0x00, 0x00 };  //odsazeni 400 pix
  byte okrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte okrX_YE[2] = { okrX_YO[0], okrX_YO[1] };
  //OKRAJ Y
  byte okrY_XO[2] = { 0x00, 0x00 };
  byte okrY_YO[2] = { okrX_YO[0], okrX_YO[1] };
  byte okrY_XE[2] = { okrY_XO[0], okrY_XO[1] };
  byte okrY_YE[2] = { 0x01, 0x90 };

  //MRIZKA X
  byte mrX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
  byte mrX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
  byte mrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte mrX_YE[2] = { mrX_YO[0], mrX_YO[1] };
  //MRIZKA Y
  byte mrY_XO[2] = { 0x00, 0x00 };  //200 pix na sirku, veprostred osy x
  byte mrY_YO[2] = { mrX_YO[0], mrX_YO[1] };
  byte mrY_XE[2] = { mrY_XO[0], mrY_XO[1] };
  byte mrY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

  short unsigned int odsazeniX = 0;
  short unsigned int odsazeniY = 0;

  nastavBarvu(1);
  nakresliUsecku(okrY_XO, okrY_YO, okrY_XE, okrY_YE, 1);
  nakresliUsecku(okrX_XO, okrX_YO, okrX_XE, okrX_YE, 2);

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniX += 60;
    if (odsazeniX < 255) {
      mrY_XO[0] = 0x00;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
    } else {
      odsazeniX -= 255;
      mrY_XO[0] = 0x01;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
      odsazeniX += 255;
      if (i == 8) {
        nastavBarvu(1);
        volbaY = 1;
      }
    }
    nakresliUsecku(mrY_XO, mrY_YO, mrY_XE, mrY_YE, volbaY);
  }

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniY += 50;
    Serial.print("Y: ");
    Serial.print(odsazeniY);
    if (odsazeniY < 255) {
      mrX_YO[0] = 0x00;
      mrX_YO[1] = 50 * i;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    } else {
      odsazeniY -= 255;
      mrX_YO[0] = 0x01;
      mrX_YO[1] = odsazeniY;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      odsazeniY += 255;
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    }
  }
  //mrX_YE[0] = mrX_YO[0]; mrX_YE[1] = mrX_YO[1];
  //nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
  nastavBarvu(3);
}


void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}

void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}
void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}
void posliPrevedeneCislo(unsigned int cislo) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cislo, bufferProCislo, 10);
  if ((cislo < 100) && (cislo >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cislo < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}

void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}

void vypisCislice(unsigned int cislo) {  //3mistny cislo


  byte poziceXNum[] = { 0x00, 0xFF };
  byte poziceYNum[] = { 0x00, 0xFF };
  byte zluta[] = { 0xFC, 0x00 };
  byte modra[] = { 0x00, 0x1F };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(poziceXNum);
  posli2Byte(poziceYNum);
  posli1Byte(0x00);  //00
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(zluta);
  posli2Byte(modra);
  posli1Byte(0x00);
  posliPrevedeneCislo(cislo);

  posliKonec();
}

int debugDotyk(bool volba) {  //FALSE ... 0X72, TRUE ... OX73
  int decMess = 0;
  bool spravnyStart = false;
  short unsigned int cursor = 1;
  int pozX[2] = { 0, 0 };
  int pozY[2] = { 0, 0 };

  Serial.print("RS232: ");
  while (true) {
    decMess = int(kom.read());
    switch (decMess) {
      case 170:
        //Serial.print("xAA ");
        spravnyStart = true;
        cursor += 1;
        break;
      case 204:
        calcX = pozX[0] * 16 * 16 + pozX[1];
        calcY = pozY[0] * 16 * 16 + pozY[1];
        //*pointerCalcX = funcCalcX;
        //*pointerCalcY = funcCalcY;
        /*
        if((calcX < 305)&&(calcY < 230)){DebugLED(10);}
        else if((calcX > 305)&&(calcY < 230)){DebugLED(9);}
        else if((calcX < 305)&&(calcY > 230)){DebugLED(11);}
        else if((calcX > 305)&&(calcY > 230)){DebugLED(12);}

        Serial.print("()()zaznam pozice X= ");Serial.print(pozX[0]);Serial.print(" ");Serial.print(pozX[1]);//zaznam x
        Serial.print(" zaznam pozice Y= ");Serial.print(pozY[0]);Serial.print(" ");Serial.print(pozY[1]);//zaznam y
        Serial.print(" pozice X= ");Serial.print(calcX);Serial.print(" pix, ");//kalkulace x
        Serial.print("pozice Y= ");Serial.print(calcY);Serial.print(" pix()() ");//kalkulace y
        */
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.print("xCC ");
        cursor += 1;
        break;
      case 60:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.println("x3C");

        cursor = 1;
        decMess = -1;
        cekamCekam = 0;
        //DebugLED(3);
        return 1;  //vse ok
        break;
      case 195:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print("xC3 ");
        cursor += 1;
        break;
      case 51:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print("x33 ");
        cursor += 1;
        break;
      case 114:
        if ((volba == true) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }  //chci 0x73
        Serial.print("xAA x72 ");
        cursor += 1;
        //pozX = int(kom.read())*16*16 + int(kom.read())*16;
        //pozY = int(kom.read())*16*16 + int(kom.read())*16;
        //Serial.print("pozice X = ");Serial.print(pozX);
        //Serial.print(", pozice Y = ");Serial.print(pozY);Serial.print(" ");
        break;
      case 115:
        if ((volba == false) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }  //chci 0x72
        Serial.print("xAA x73 ");
        cursor += 1;
        break;
      case -1:  //SKIP
        cekamCekam += 1;
        if (cekamCekam == 10) {
          Serial.println("NULL");
          cekamCekam = 0;
          //DebugLED(5);
          return 3;
        }
        break;
      default:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print(decMess);
        if (cursor == 3) { pozX[0] = decMess; }
        if (cursor == 4) { pozX[1] = decMess; }
        if (cursor == 5) { pozY[0] = decMess; }
        if (cursor == 6) { pozY[1] = decMess; }
        cursor += 1;
        Serial.print(" ");
        break;
    }
  }
}
