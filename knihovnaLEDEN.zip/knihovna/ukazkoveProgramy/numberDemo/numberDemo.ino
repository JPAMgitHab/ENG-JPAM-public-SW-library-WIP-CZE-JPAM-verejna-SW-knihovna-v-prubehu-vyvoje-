#include <SPI.h>
#include <SoftwareSerial.h>
#include <SD.h>

const int chipSelectSD = 6;
File dataFile;

#define rx 7
#define tx 8

int calcX = 0;
int calcY = 0;

int poleCisel[10]={0,0,0,0,0,0,0,0,0,0};
short int cursor;

unsigned int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };

SoftwareSerial kom(rx, tx);  // RX, TX

void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cislo);
void DebugLED(int pin);
int debugDotyk(bool volba);  //FALSE ... 0X72, TRUE ... OX73
//int dotykSouradnice(bool volba);//FALSE ... 0X72, TRUE ... OX73
void charCislaNaHexZpravu(char znak);
void vypisCislice(unsigned int cislo);
void bargraf(unsigned int cislo);

void setup() {
  //Serial.begin(115200);
  kom.begin(9600);
  pinMode(A0, OUTPUT);

    Serial.print("SD: inicializace");
  if (!SD.begin(chipSelectSD)) {
    Serial.println(" neuspesna");
  } else {
    Serial.println(" uspesna");
  }
  dataFile = SD.open("data.csv");
  if (dataFile == 1) {
    Serial.println("SD: nasel se .csv soubor");
  } else {
    Serial.println("SD: nenasel se .csv soubor");
  }
  dataFile.close();
}

void loop() {//HLAVNI SMYCKA

prectenaHodnota = analogRead(A0);

prectenaHodnota /= 4; //max 1023/4 = max 255

  vypisCislice(prectenaHodnota);
  bargraf(prectenaHodnota);
  //Serial.print("TRIMR: ");
  //Serial.print(prectenaHodnota);

popelnice = debugDotyk(false);  //FALSE ... 0X72, TRUE ... OX73

//int poleCisel[10]={0,0,0,0,0,0,0,0,0,0};
//short int cursor;

if(popelnice == 1)//vse je ok
{
  if((calcX <= 380)&&(calcX >= 160)){
    else if((calcY <= 220)&&(calcY >= 160)){//SAVE
    if (dataFile == 1) { // soubor je dostupny pro zapis
      dataFile.print("Sekvence cisel: ");
      for(int i = 0; i < 10; i++){dataFile.print(poleCisel[i]);}
      dataFile.println("");
       dataFile.close();
    }
    else{vypisCislice(333);delay(150);}
    }

    else if((calcY <= 300)&&(calcY >= 240)){//WRITE 
      cursor += 1;
      if(cursor > 10){cursor = o;}
      poleCisel[cursor] = prectenaHodnota;
    }

    else if((calcY <= 380)&&(calcY >= 320)){//ERASE
      for(int i = 0; i < 10; i++){poleCisel[i] = 0;}
    }
  }

}
}

void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}
void DebugLED(int pin) {
  digitalWrite(pin, HIGH);
  delay(10);
  digitalWrite(pin, LOW);
}
void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}
void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}
void posliPrevedeneCislo(unsigned int cislo) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cislo, bufferProCislo, 10);
  if ((cislo < 100) && (cislo >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cislo < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}
void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}
void vypisCislice(unsigned int cislo) {  //3mistny cislo


  byte poziceXNum[] = { 0x00, 0xDD };
  byte poziceYNum[] = { 0x00, 0xDD };
  byte BLACK[] = { 0xFF, 0xFF };
  byte WHITE[] = { 0x00, 0x00 };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(poziceXNum);
  posli2Byte(poziceYNum);
  posli1Byte(0x00);  //00
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(BLACK);
  posli2Byte(WHITE);
  posli1Byte(0x00);
  posliPrevedeneCislo(cislo);
  posliKonec();
}
debugDotyk(bool volba) {  //FALSE ... 0X72, TRUE ... OX73
  int decMess = 0;
  bool spravnyStart = false;
  short unsigned int cursor = 1;
  int pozX[2] = { 0, 0 };
  int pozY[2] = { 0, 0 };

  Serial.print("RS232: ");
  while (true) {
    decMess = int(kom.read());
    switch (decMess) {
      case 170:
        //Serial.print("xAA ");
        spravnyStart = true;
        cursor += 1;
        break;
      case 204:
        calcX = pozX[0] * 16 * 16 + pozX[1];
        calcY = pozY[0] * 16 * 16 + pozY[1];
        //*pointerCalcX = funcCalcX;
        //*pointerCalcY = funcCalcY;
        /*
        if((calcX < 305)&&(calcY < 230)){DebugLED(10);}
        else if((calcX > 305)&&(calcY < 230)){DebugLED(9);}
        else if((calcX < 305)&&(calcY > 230)){DebugLED(11);}
        else if((calcX > 305)&&(calcY > 230)){DebugLED(12);}

        Serial.print("()()zaznam pozice X= ");Serial.print(pozX[0]);Serial.print(" ");Serial.print(pozX[1]);//zaznam x
        Serial.print(" zaznam pozice Y= ");Serial.print(pozY[0]);Serial.print(" ");Serial.print(pozY[1]);//zaznam y
        Serial.print(" pozice X= ");Serial.print(calcX);Serial.print(" pix, ");//kalkulace x
        Serial.print("pozice Y= ");Serial.print(calcY);Serial.print(" pix()() ");//kalkulace y
        */
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.print("xCC ");
        cursor += 1;
        break;
      case 60:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.println("x3C");

        cursor = 1;
        decMess = -1;
        cekamCekam = 0;
        DebugLED(3);
        return 1;  //vse ok
        break;
      case 195:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          DebugLED(4);
          return 2;
        }
        Serial.print("xC3 ");
        cursor += 1;
        break;
      case 51:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          DebugLED(4);
          return 2;
        }
        Serial.print("x33 ");
        cursor += 1;
        break;
      case 114:
        if ((volba == true) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          DebugLED(4);
          return 2;
        }  //chci 0x73
        Serial.print("xAA x72 ");
        cursor += 1;
        //pozX = int(kom.read())*16*16 + int(kom.read())*16;
        //pozY = int(kom.read())*16*16 + int(kom.read())*16;
        //Serial.print("pozice X = ");Serial.print(pozX);
        //Serial.print(", pozice Y = ");Serial.print(pozY);Serial.print(" ");
        break;
      case 115:
        if ((volba == false) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          DebugLED(4);
          return 2;
        }  //chci 0x72
        Serial.print("xAA x73 ");
        cursor += 1;
        break;
      case -1:  //SKIP
        cekamCekam += 1;
        if (cekamCekam == 10) {
          Serial.println("NULL");
          cekamCekam = 0;
          DebugLED(5);
          return 3;
        }
        break;
      default:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          DebugLED(4);
          return 2;
        }
        Serial.print(decMess);
        if (cursor == 3) { pozX[0] = decMess; }
        if (cursor == 4) { pozX[1] = decMess; }
        if (cursor == 5) { pozY[0] = decMess; }
        if (cursor == 6) { pozY[1] = decMess; }
        cursor += 1;
        Serial.print(" ");
        break;
    }
  }
}

void bargraf(unsigned int cislo){
  byte poziceX[] = { 0x01, 0xDD };
  byte poziceY[] = { 0x01, 0xDD };

  
  int barNumb = val = map(val, 0, 255, 0, 100);

  for(int i = barNumb;i<= 100;i++){//bila
  posliZacatek();
  posli1Byte(0x5D);
  posli2Byte({0x0F - i,0xFF});//LEVY KRAJ
  posli2Byte({0x4F,0xFF});
  posli2Byte({0x0F + 10,0xFF});//PRAVY KRAJ
  posli2Byte({0x5F,0xFF});
  posliKonec();
  }

  for(int j = 0;j<= barNumb;j++){//cerna
  posliZacatek();
  posli1Byte(0x56);
  posli2Byte({0x0F - j,0xFF});//LEVY KRAJ
  posli2Byte({0x4F,0xFF});
  posli2Byte({0x0F + 10,0xFF});//PRAVY KRAJ
  posli2Byte({0x5F,0xFF});
  posliKonec();
  }
  
  bargraf pri kazdem volani sam ,,vycisti" barvou pozadi
}