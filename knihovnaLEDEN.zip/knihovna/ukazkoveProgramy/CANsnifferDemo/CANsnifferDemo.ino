
#include <mcp_can.h>
#include <SPI.h>
#include <SoftwareSerial.h>

#define rx 7
#define tx 8

int calcX = 0;
int calcY = 0;

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];

unsigned int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };

SoftwareSerial kom(rx, tx);  // RX, TX
MCP_CAN CAN0(10);            

void printRxCAN();
void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cislo);
void DebugLED(int pin);

int debugDotyk(bool volba);  //FALSE ... 0X72, TRUE ... OX73
//int dotykSouradnice(bool volba);//FALSE ... 0X72, TRUE ... OX73
void charCislaNaHexZpravu(char znak);
void vypisCislice(byte X[2],byte Y[2],unsigned int cislo);

void setup() {
  Serial.begin(115200);
  kom.begin(9600);
  CAN0.begin(CAN_500KBPS);  
  pinMode(2, INPUT);        


}

void loop() {//HLAVNI SMYCKA


  //CAN
  if (!digitalRead(2))  
  {
    CAN0.readMsgBuf(&len, rxBuf);  
    rxId = CAN0.getCanId();        
    if (rxId == 0x15F772F5) {
      //printRxCAN();
      prectenaHodnota = rxBuf[cursor];
      vypisCislice({0x01,0x00},{0x00,0xE0},cursor);
      vypisCislice({0x01,0x00},{0x01,0x00},prectenaHodnota);
      //itoa(prectenaHodnota, bufferProCislo, 10);
    } else {
      //Serial.println("CAN: NULL");
    }
  } else {
    //Serial.println("CAN: FAIL");
  }


  popelnice = debugDotyk(true);  //FALSE ... 0X72, TRUE ... 0X73

  if (popelnice == 1) {          //1.. ok, 3 .. neni co cist, 2 ... chybne podminky
    if((calcY <= 240)&&(calcY >= 180)){
    else if((calcX <= 160)&&(calcX >= 30)){//R
      cursor -= 1;
      if(cursor < 0){cursor = 0;}
    }
    else if((calcX <= 440)&&(calcX >= 320)){//G
      cursor += 1;
      if(cursor > 10){cursor = 10;}
    }

  }
  }
}


void printRxCAN() {
  Serial.print("CAN: ");
  Serial.print("ID: ");
  Serial.print(rxId, HEX);

  Serial.print("  Data: ");
  for (int i = 0; i < len; i++)  
  {
    if (rxBuf[i] < 0x10)  
    {
      Serial.print("0");
    }
    Serial.print(rxBuf[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

}
void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}
void DebugLED(int pin) {
  digitalWrite(pin, HIGH);
  delay(10);
  digitalWrite(pin, LOW);
}
void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}
void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}
void posliPrevedeneCislo(unsigned int cislo) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cislo, bufferProCislo, 10);
  if ((cislo < 100) && (cislo >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cislo < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}
void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}
void vypisCislice(byte X[2],byte Y[2],unsigned int cislo) {  //3mistny cislo


  byte poziceXNum[] = { 0x00, 0xFF };
  byte poziceYNum[] = { 0x00, 0xFF };
  byte BLACK[] = { 0xFF, 0xFF };
  byte WHITE[] = { 0x00, 0x00 };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(X);
  posli2Byte(Y);
  posli1Byte(0x00);  //00
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(BLACK);
  posli2Byte(WHITE);
  posli1Byte(0x00);
  posliPrevedeneCislo(cislo);

  posliKonec();
}


