
#include <mcp_can.h>
#include <SPI.h>
#include <SoftwareSerial.h>
#include <SD.h>

const int chipSelectSD = 6;
//File dataFile;
unsigned long int cycleCount = 0;
#define rx 3
#define tx 4

unsigned short int calcX = 0;
unsigned short int calcY = 0;

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];
//char msgString[128];

//zkouska posilani zpravy
byte testovaciZprava0[8] = { 0x00, 0x80, 0b00000001, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
byte CANTxOK = 0xFF;
byte CANkonfigurace = 0x00;
bool snimacVCC = false;
bool tlacitka = false;
unsigned long const int ZZ_CTRL = 0x15F773F5;
unsigned long const int ZZ_SET = 0x15F774F5;
unsigned long const int ZZ_INF1 = 0x15F771F5;  //krokac
unsigned long const int ZZ_INF2 = 0x15F772F5;  //pwm

int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };


SoftwareSerial kom(rx, tx);
#define CAN0_INT 2
MCP_CAN CAN0(10);

void CANpocatecniProcedura();
void CANmotor(bool volba, int pocetKroku);  //0 ... doleva, 1 ... doprava
void jedMotor(bool volba,int pocetOpak);
void CANvypisovacismycka(long unsigned int rxIdX);
short int tlacitkoKrok = 1;

//void printRxCAN();
void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cisloX);

void charCislaNaHexZpravu(char znak);
void vypisCislice(unsigned int cisloX);
int vysledek = 0;

/////////////////////////////////////////////////////////////////////////
/*
implementace prace s GUI prostrednictvim dotyku a prepinani ulozenych obrazku v displeji 
*/

int dotykRychlejsi();  //prikazy 0x72 a 0x73
void prepnutiObrazku(short unsigned int volba);
const byte prikazObraz = 0x70;
short int predeslyObr = 0;

#define IDGUI_uvod 0
#define IDGUI_UMenu 1
#define IDGUI_kontrola 4
#define IDGUI_manual 3
#define IDGUI_kalibrace 2
#define IDGUI_cchGRAF 5
#define IDGUI_linGRAF 6
#define IDGUI_mereniD 8
#define IDGUI_mereniK 7
#define IDGUI_snimac 9

void GUIuvodniMenu();
void GUImanual();
void GUIkontrola();
void GUIkalibrace();
void GUImereniD();
void GUImereniK();
void GUIgrafChar();
void GUIgrafLin();
//void GUImereni();
//void GUImereniH();
void GUIsnimac(short int bodNavratu);
void GUIPWM();
//funkce a hodnoty pro kresbu a praci s grafem
//
unsigned short int recordID = 0;
const byte BLACK[2] = { 0x00, 0x00 };
const byte WHITE[2] = { 0xFF, 0xFF };
const byte GREEN[2] = { 0x07, 0x00 };
const byte RED[2] = { 0xF8, 0x00 };

//OSA X
byte osaX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
byte osaX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
byte osaX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
byte osaX_YE[2] = { osaX_YO[0], osaX_YO[1] };
//OSA Y
byte osaY_XO[2] = { 0x00, 0xF0 };  //200 pix na sirku, veprostred osy x
byte osaY_YO[2] = { osaX_YO[0], osaX_YO[1] };
byte osaY_XE[2] = { osaY_XO[0], osaY_XO[1] };
byte osaY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

//"stredova" osa
//byte stred_XO[2] = {osaX_XO[0], osaX_XO[1]};
//byte stred_YO[2] = { 0x00, 0xC8 };  //200 pix na vysku
//byte stred_XE[2] = {osaX_XE[0], osaX_XE[1]};
//byte stred_YE[2] = {stred_YO[0], stred_YO[1]};  //50 pix na vysku

const short unsigned int velikostPole = 250;
short int Yhodnoty[velikostPole];  // y = 200 * (sin(x) + 1 )
/*specialni hodnota 300*/

/*
volba = 1 -> CERNA/BILA
volba = 2 -> CERVENA/BILA
volba = 3 -> ZELENA/BILA
*/

void nastavBarvu(short unsigned int volba);
void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba);
void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]);
void mrizka();
/////////////////////////////////////////////////////////////////////////

//const byte GREEN[2] = { 0x07, 0x00 };
//const byte RED[2] = { 0xF8, 0x00 };

void vybarviPolicko(byte barva[2], byte X[2], byte Y[2]);
const byte kalibraceX[2] = { 0x01, 0x40 };
const byte kalibraceY[2] = { 0x00, 0xFB };
const byte kalibraceX1[2] = { 0x00, 0x28 };  //LH
const byte kalibraceY1[2] = { 0x00, 0x19 };
const byte kalibraceX2[2] = { 0x00, 0x28 };  //LS
const byte kalibraceY2[2] = { 0x01, 0xC2 };
const byte kalibraceX3[2] = { 0x02, 0x58 };  //PH
const byte kalibraceY3[2] = { 0x00, 0x19 };
const byte kalibraceX4[2] = { 0x02, 0x58 };  //PS
const byte kalibraceY4[2] = { 0x01, 0xC2 };

const byte kontrolaX[2] = { 0x01, 0xDB };
const byte kontrolaY1[2] = { 0x00, 0x87 };
const byte kontrolaY2[2] = { 0x00, 0xAF };
const byte kontrolaY3[2] = { 0x00, 0xDC };
const byte kontrolaY4[2] = { 0x01, 0x14 };

byte poziceXNum[] = { 0x01, 0x37 };
byte poziceYNum[] = { 0x01, 0xD8 };
short int cislo = 0;


void zabzuc(short unsigned int pocetOpak, short int cas);

void SDpocatecniProcedura();
void vymazaniPole();
void SDukladaniPole(short int pocCisloMereni);//1...kratke mereni, 2...dlouhe mereni
unsigned short int cisloMereni = 1;
byte tolerance = 0x08;
unsigned short int krokMK1 = 15; 
unsigned short int krokMK2 = 2;
unsigned short int krokMD1 = 1;  
unsigned short int krokSnimac = 3;

unsigned short int LINlevaMez = 110;  
unsigned short int LINpravaMez = 150;  
unsigned short int koneck = 220;  


void setup() {
  Serial.begin(115200);
  kom.begin(57600);

  // nastaveni LEDek
  pinMode(A1, OUTPUT);
  pinMode(A2, OUTPUT);
  pinMode(A3, OUTPUT);
  pinMode(A4, OUTPUT);
  pinMode(A5, OUTPUT);

  pinMode(10, OUTPUT);
  digitalWrite(10,HIGH);

  //for(int i = 0; i <= 8;i++){prepnutiObrazku(i);delay(1000);}
  delay(2000);
  //digitalWrite(A5, HIGH);

  //CANpocatecniProcedura();
  //GUIuvodniMenu();
  SD.begin(chipSelectSD);
  GUIkontrola();
  //testovaciZprava0[3] = 0b00000001;
}

int kZahozeni = 0;

void jedMotor(bool volba,int pocetOpak){
  for(int i; i < pocetOpak;i++){CANmotor(volba,1);}
}

void loop() {
  kZahozeni = dotykRychlejsi();
}

void vymazaniPole(){
  for(int i = 0; i < velikostPole; i++){
    Yhodnoty[i] = 300; //300 je nemozna hodnota mimo rozsah PWM (tzn. mimo rozsah 0 - 255), tim si znacim prazdny polek pole
  }
}

void GUIPWM(){
  const byte XS1[2] = {0x01,0xA3};//dec 424
  const byte YS1[2] = {0x01,0x7C};//dec 382
  const byte XE1[2] = {0x02,0x14};//dec 532
  const byte YE1[2] = {0x01,0xE0};//dec 480

  posliZacatek();//prikaz 0x71 manual DWIN, str.15, kapitola 2.13.3
  posli1Byte(0x71);
  posli1Byte(IDGUI_mereniD);
  posli2Byte(XS1);
  posli2Byte(YS1);
  posli2Byte(XE1);
  posli2Byte(YE1);
  posli2Byte(XS1);
  posli2Byte(YS1);
  posliKonec();
}

void GUImereniD(){
  prepnutiObrazku(IDGUI_mereniD);
  
  vymazaniPole();

  //byte tolerance = 0x0F;
  //unsigned short int krokMK1 = 30; 
  //unsigned short int krokMK2 = 5;
  //unsigned short int krokMD1 = 1;  
  //unsigned short int LINlevaMez = 110;  
  //unsigned short int LINpravaMez = 110; 


  vybarviPolicko(RED, kontrolaX, kontrolaY1);
  vybarviPolicko(RED, kontrolaX, kontrolaY2);
  vybarviPolicko(RED, kontrolaX, kontrolaY3);
  vybarviPolicko(RED, kontrolaX, kontrolaY4);
  
  File dataFile = SD.open("DATA.CSV",FILE_WRITE);
  if(dataFile){vypisCislice(111);vybarviPolicko(GREEN, kontrolaX, kontrolaY1);}
  //dataFile = SD.open("DATA.CSV",FILE_WRITE);
  else{
    vypisCislice(222);
    while (1) {
      kZahozeni = dotykRychlejsi();
      if (kZahozeni) {
        if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
      }
    }

  }
  
  dataFile.print("ZMD");dataFile.print(cisloMereni);dataFile.println(";");cisloMereni += 1;
  dataFile.print("Cislo hodnoty;");dataFile.println("PWM dec [-];");


  while(dotykRychlejsi() != 1){//NAJDI NULU, jed doleva dokud nenajdu nulu
    CANmotor(0,3);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);

    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 0x00 && rxBuf[0] < tolerance)){
      //Serial.println("NULA USPECH");
      zabzuc(1,50);
      break;
    }
  } 

  vybarviPolicko(GREEN, kontrolaX, kontrolaY2);

  for(int i = 0; i < 1000;i++){//MERENI

    if(dotykRychlejsi() == 1){break;}
    CANmotor(1,1);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);//precti zpravu
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];//zobraz vyfiltrovane PWM
    vypisCislice(cislo);

    dataFile.print(i);dataFile.print(";");dataFile.print(cislo);dataFile.println(";");

    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 240 && rxBuf[0] < 255)){//konec
      vybarviPolicko(GREEN, kontrolaX, kontrolaY3);
      break;
    }

    cislo = rxBuf[0];//zobraz vyfiltrovane PWM
    vypisCislice(cislo);

  } 

    vybarviPolicko(GREEN, kontrolaX, kontrolaY4);
    dataFile.close();
    
    
    while (1) {
      kZahozeni = dotykRychlejsi();
      if (kZahozeni) {
        if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
      }
    }
  

  

  //vybarviPolicko(GREEN, kontrolaX, kontrolaY4);
  vymazaniPole();
  //------------------------------------------------------------------
  
  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
    }
  }
}

void GUImereniK(){
  vymazaniPole();

  //byte tolerance = 0x0F;
  //unsigned short int krokMK1 = 30; 
  //unsigned short int krokMK2 = 5;
  //unsigned short int krokMD1 = 1;  
  //unsigned short int LINlevaMez = 110;  
  //unsigned short int LINpravaMez = 110; 

  prepnutiObrazku(IDGUI_mereniK);

  vybarviPolicko(RED, kontrolaX, kontrolaY1);
  vybarviPolicko(RED, kontrolaX, kontrolaY2);
  vybarviPolicko(RED, kontrolaX, kontrolaY3);
  vybarviPolicko(RED, kontrolaX, kontrolaY4);
  
  File dataFile = SD.open("DATA.CSV",FILE_WRITE);
  if(dataFile){vypisCislice(111);vybarviPolicko(GREEN, kontrolaX, kontrolaY1);}
  //dataFile = SD.open("DATA.CSV",FILE_WRITE);
  else{
    vypisCislice(222);
    while (1) {
      kZahozeni = dotykRychlejsi();
      if (kZahozeni) {
        if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
      }
    }

  }
  
  dataFile.print("ZMK");dataFile.print(cisloMereni);dataFile.println(";");cisloMereni += 1;
  dataFile.print("Cislo hodnoty;");dataFile.println("PWM dec [-];");


  while(dotykRychlejsi() != 1){//NAJDI NULU, jed doleva dokud nenajdu nulu
    CANmotor(0,3);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);

    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 0x00 && rxBuf[0] < tolerance)){
      //Serial.println("NULA USPECH");
      zabzuc(1,50);
      break;
    }
  } 

  vybarviPolicko(GREEN, kontrolaX, kontrolaY2);

  for(int i = 0; i < 250;i++){//MERENI

    if(dotykRychlejsi() == 1){break;}
    CANmotor(1,4);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);//precti zpravu
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];//zobraz vyfiltrovane PWM
    vypisCislice(cislo);

    dataFile.print(i);dataFile.print(";");dataFile.print(cislo);dataFile.println(";");

    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 240 && rxBuf[0] < 255)){//konec
      vybarviPolicko(GREEN, kontrolaX, kontrolaY3);
      break;
    }

    cislo = rxBuf[0];//zobraz vyfiltrovane PWM
    vypisCislice(cislo);

  } 

    vybarviPolicko(GREEN, kontrolaX, kontrolaY4);
    dataFile.close();
    
    
    while (1) {
      kZahozeni = dotykRychlejsi();
      if (kZahozeni) {
        if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
      }
    }
  

  

  //vybarviPolicko(GREEN, kontrolaX, kontrolaY4);
  vymazaniPole();
  //------------------------------------------------------------------
  
  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
    }
  }
}

void GUIgrafChar(){
  prepnutiObrazku(IDGUI_cchGRAF);

  while (1) {
    kZahozeni = dotykRychlejsi();
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);
    if (kZahozeni) {
      if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
    }
  }
}

void GUIgrafLin(){
  prepnutiObrazku(IDGUI_linGRAF);
  while (1) {
    kZahozeni = dotykRychlejsi();
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);
    if (kZahozeni) {
      if (calcX > 530 && calcY > 383) { GUIuvodniMenu(); }
    }
  }
}

void CANvypisovacismycka(long unsigned int rxIdX) {
  while (1) {  //vzpisovaci smycka
    if (!digitalRead(CAN0_INT)) {
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == rxIdX) {
        /*Serial.print("CAN ID:");Serial.print(rxId,HEX);Serial.print(" Data: ");
        for (byte i = 0; i < len; i++) {
          //sprintf(msgString, " 0x%.2X", rxBuf[i]);
          Serial.print(rxBuf[i],HEX);
          Serial.print(" ");
        }
        Serial.println();*/
        break;
      }
    }
  }
}

void GUIsnimac(short int bodNavratu){
  //Serial.print("HODNOTA: ");Serial.println(predeslyObr);
  prepnutiObrazku(IDGUI_snimac);
  kZahozeni = 0;
    vybarviPolicko(RED, kontrolaX, kontrolaY1);
    vybarviPolicko(RED, kontrolaX, kontrolaY2);
    vybarviPolicko(RED, kontrolaX, kontrolaY3);
    vybarviPolicko(RED, kontrolaX, kontrolaY4);
  //snimacVCC = false;
  GUIPWM();

  if(snimacVCC == true){vybarviPolicko(GREEN, kontrolaX, kontrolaY1);}
  
  else{
    while (1) {
      kZahozeni = dotykRychlejsi();
      if (kZahozeni) {
        if (calcX > 550 && calcY > 420) {GUIuvodniMenu();}}
    }
  }
  
  //zacne hledni 50% PWM a stredove pozice motoru 
  kZahozeni = 0;
  zabzuc(1,10);
  
  while(dotykRychlejsi() != 1){//NAJDI NULU
    CANmotor(1,krokSnimac);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);

    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 0x00 && rxBuf[0] < tolerance)){
      //Serial.println("NULA USPECH");
      zabzuc(1,30);
      break;
    }
    //kZahozeni = dotykRychlejsi();
  } 

  zabzuc(1,10);
  while(dotykRychlejsi() != 1){//NAJDI STRED
    CANmotor(1, krokSnimac);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    vypisCislice(cislo);
    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > (0x71 - tolerance) && rxBuf[0] < (0x71 + tolerance))){
      //Serial.println("STRED USPECH");
      zabzuc(1,50);
      vybarviPolicko(GREEN, kontrolaX, kontrolaY2);//uspech hledni 50% PWM a stredove pozice motoru 
      vybarviPolicko(GREEN, kontrolaX, kontrolaY3);

      vybarviPolicko(GREEN, kontrolaX, kontrolaY4);//vsechno splneno
      delay(1500);//mensi pauza, aby byl vysledek viditelny
      /*z vyjimecnych duvodu pouziju trojici if podminek, kod bude prehlednejsi*/
      if(bodNavratu == IDGUI_cchGRAF){GUIgrafChar();}
      else if(bodNavratu == IDGUI_linGRAF){GUIgrafLin();}
      else if(bodNavratu == IDGUI_mereniD){GUImereniD();}
      else if(bodNavratu == IDGUI_mereniK){GUImereniK();}
      break;
      }
    //kZahozeni = dotykRychlejsi();
  } //konec while smycky

  
  //---------------------------------------------------------

  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 550 && calcY > 420) {GUIuvodniMenu();}
    }
  }

}

void SDpocatecniProcedura() {
  vybarviPolicko(RED, kontrolaX, kontrolaY1);
  vybarviPolicko(RED, kontrolaX, kontrolaY2);
  vybarviPolicko(RED, kontrolaX, kontrolaY3);
  vybarviPolicko(RED, kontrolaX, kontrolaY4);

  //if(SD.begin(chipSelectSD)){/*Serial.println("SD: karta je OK.");*/vybarviPolicko(GREEN, kontrolaX, kontrolaY1);}//FUNKCE KONTROLY/OBRAZEK KONTROLA
  
  //dataFile = SD.open("DATA.CSV");
  //if(dataFile){dataFile.close();/*Serial.println("SD: soubor je OK.");dataFile.close();*/vybarviPolicko(GREEN, kontrolaX, kontrolaY2);}//FUNKCE KONTROLY/OBRAZEK KONTROLA
  
  vybarviPolicko(GREEN, kontrolaX, kontrolaY3);//rs komunikace musi byt v poradku, kdyz uspesne JPAM prepne obrazek, FUNKCE KONTROLY/OBRAZEK KONTROLA

  /*
  if (SD.exists("KLBR.CSV")) {
    //dataFile.close();
    Serial.println("SD: KLBR.CSV nalezena.");
    //SD_OK = true;
  } else {
    Serial.println("SD: KLBR.CSV nenalezena.");
  }
  */

  //dataFile = SD.open("CONFIG.TXT", FILE_WRITE);
  //if (dataFile) {dataFile.close();vybarviPolicko(GREEN, kontrolaX, kontrolaY2);}
  //else{}
}

void CANmotor(bool volba, int pocetKroku) {  //0 ... doleva, 1 ... doprava
  byte motor[2] = { 0x00, 0x00 };
 //short int tlacitkoKrok = 1;
  while (1) {
    if (!digitalRead(CAN0_INT)) {  //precti si prichozi motorovou zpravu a uloz si posledni stav motoru
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == ZZ_INF1) {
        //Serial.println("CAN: zprava se opravdu prepsala");
        motor[0] = rxBuf[2]; //prepis low byte
        motor[1] = rxBuf[3]; //prepis high byte
        break;
      }
    }
  }  //mam pozici motoru

  if (volba == 0) {  //motor se otaci doleva
    if (motor[0] == 0x00) {
      motor[0] == 0xFF; //uz tady jedu doleva o 1 krok
      motor[1] -= 0x01;

      motor[0] -= pocetKroku - 1;
    } else {
      motor[0] -= pocetKroku;
    }
  } 
  
  else if (volba == 1) {  //motor se otaci doprava
    if (motor[0] == 0xFF) {
      motor[0] == 0x00;
      motor[1] += 0x01;//uz tady jedu doprava o 1 krok

      motor[0] += pocetKroku - 1;
    } else {
      motor[0] += pocetKroku;
    }
  }

  testovaciZprava0[0] = motor[0];
  testovaciZprava0[1] = motor[1];

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);  //posli zpravu pro uklidneni motoru a povoleni mereni PWM
  
  if (CANTxOK == CAN_OK) {
    //Serial.println("CAN: motor zprava uspesne poslana");
  } else {
    //Serial.println("CAN: motor zprava nedorazila");
  }

}


void CANpocatecniProcedura() {

  if (CAN0.begin(MCP_ANY, CAN_500KBPS, MCP_16MHZ) == CAN_OK){
    //Serial.println("CAN: MCP2515 se bavi");
    vybarviPolicko(GREEN, kontrolaX, kontrolaY4);
    }
    
  else{
    //Serial.println("CAN: MCP2515 se nebavi");
    vybarviPolicko(RED, kontrolaX, kontrolaY4);
    }

  CAN0.setMode(MCP_NORMAL);

  pinMode(CAN0_INT, INPUT);

  //Serial.println("CAN: MCP2515 zkouska posilani a prijmu zprav");

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);
  if (CANTxOK == CAN_OK) {
    //Serial.println("CAN: pocatecni zprava uspesne poslana");
  } else {
    //Serial.println("CAN: pocatecni zprava nedorazila");
  }

  while (1) {
    if (!digitalRead(CAN0_INT)) {  //precti si prichozi motorovou zpravu a uloz si posledni stav motoru
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == ZZ_INF1) {
        //Serial.println("CAN: zprava se opravdu prepsala");
        testovaciZprava0[0] = rxBuf[2];
        testovaciZprava0[1] = rxBuf[3];
        break;
      }
    }
  }

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);  //posli zpravu pro uklidneni motoru a povoleni mereni PWM
  if (CANTxOK == CAN_OK) {
    //Serial.println("CAN: prepsana zprava uspesne poslana");
  } else {
    //Serial.println("CAN: prepsana zprava nedorazila");
  }
  /*
  while (1) {
    if (!digitalRead(CAN0_INT)) {
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == ZZ_INF1) {
        sprintf(msgString, "Standard ID: 0x%.3lX       DLC: %1d  Data:", rxId, len);  //z ukazky v knihovne modfikovane pro sobni ucely
        Serial.print(msgString);

        for (byte i = 0; i < len; i++) {
          sprintf(msgString, " 0x%.2X", rxBuf[i]);
          Serial.print(msgString);
        }
        Serial.println();
      }
    }
  }
  */
}

void zabzuc(short unsigned int pocetOpak, short int cas) {
  if (pocetOpak < 5 && pocetOpak > 0 && cas > 0 && cas < 255) {
    for (int i = 0; i < pocetOpak; i++) {
      posliZacatek();
      posli1Byte(0x79);
      posli1Byte(cas);
      posliKonec();
    }
  }
}

//const byte GREEN[2] = { 0x07, 0x00 };
//const byte RED[2] = { 0xF8, 0x00 };
void vybarviPolicko(byte barva[2], byte X[2], byte Y[2]) {
  posliZacatek();
  posli1Byte(0x64);
  posli2Byte(X);
  posli2Byte(Y);
  posli2Byte(barva);
  posliKonec();
}

void GUIuvodniMenu() {
  //Serial.println(testovaciZprava0[3],BIN);
  prepnutiObrazku(IDGUI_UMenu);

  while (1) {
    kZahozeni = dotykRychlejsi();
    //if(souradnice(110,210,330,380)){GUIkontrola();}
    //else if(souradnice(270,370,330,380)){GUImereniH();}
    //else if(souradnice(430,530,330,380)){GUIkalibrace();}
    if (kZahozeni) {
      if (calcY > 160 && calcY < 220) {//1.radek tlacitek
        if (calcX > 47 && calcX < 184) {GUIsnimac(IDGUI_cchGRAF);}//graf cele char
        else if (calcX > 185 && calcX < 322) {GUIsnimac(IDGUI_linGRAF);}//graf lin. casti
        else if (calcX > 323 && calcX < 458) {GUIsnimac(IDGUI_mereniK);}//K mereni
        else if (calcX > 459 && calcX < 594) {GUIsnimac(IDGUI_mereniD);}//D mereni
      } 
      else if (calcY > 221 && calcY < 276) {//2.radek tlacitek
        if (calcX > 169 && calcX < 274) { GUIkontrola(); }
        if (calcX > 275 && calcX < 380) { GUImanual(); }
        if (calcX > 380 && calcX < 480) { GUIkalibrace(); }
      }
      else if(calcX > 57 && calcX < 587 && calcY > 330 && calcY < 440){//3.radek tlacitek
        //4tlacitka
        //0b00000001
        if(calcX < 320 && calcY < 382){//M028 VCC ON
          CANkonfigurace |= 0b00000100; snimacVCC = true;
          }
        else if(calcX < 320 && calcY > 382){//M028 VCC OFF
          CANkonfigurace = 0b00000001; snimacVCC = false;
          if(tlacitka == true){CANkonfigurace |= 0b00000010;}
          }
        else if(calcX > 320 && calcY < 382){//TLACITKA JO
          CANkonfigurace |= 0b00000010;digitalWrite(A5, HIGH); tlacitka = true;
          }
        else if(calcX > 320 && calcY > 382){//TLACITKA NE
          CANkonfigurace = 0b00000001;tlacitka = false; digitalWrite(A5, LOW);
          if(snimacVCC == true){CANkonfigurace |= 0b00000100;}
          }
        
      //CANkonfigurace = bitClear(CANkonfigurace,2-1);
        testovaciZprava0[2] = CANkonfigurace;//prepis si byte konfigurace podle volby uzivatele

        while (1) {
          if (!digitalRead(CAN0_INT)) {  //precti si prichozi motorovou zpravu a uloz si posledni stav motoru
            CAN0.readMsgBuf(&rxId, &len, rxBuf);
            rxId -= 0x80000000;
            if (rxId == ZZ_INF1) {
              //Serial.println("CAN: zprava se opravdu prepsala");
              testovaciZprava0[0] = rxBuf[2];
              testovaciZprava0[1] = rxBuf[3];
              break;
            }
          }
        }

        //Serial.println(testovaciZprava0[3],BIN);
        
        CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);  //posli zpravu pro uklidneni motoru a povoleni mereni PWM
  
        if (CANTxOK == CAN_OK) {/*Serial.println("CAN: konf zprava uspesne poslana");*/zabzuc(1,50);} 
        else {zabzuc(1,10);}
      }//KONEC JUMBO PODMINKY O KONFIGURACI ZZ
    }
  }
}

void GUImanual() {
  prepnutiObrazku(IDGUI_manual);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 550 && calcY > 420) { GUIuvodniMenu(); }
    }
  }
}

void GUIkontrola() {
  prepnutiObrazku(IDGUI_kontrola);
  SDpocatecniProcedura();
  CANpocatecniProcedura();
  
  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 550 && calcY > 420) { GUIuvodniMenu(); }
    }
  }
}

void GUIkalibrace() {
  prepnutiObrazku(IDGUI_kalibrace);

  bool dotknulLH = false;
  bool dotknulLS = false;
  bool dotknulPH = false;
  bool dotknulPS = false;

  vybarviPolicko(RED, kalibraceX, kalibraceY);
  vybarviPolicko(RED, kalibraceX1, kalibraceY1);  //LH
  vybarviPolicko(RED, kalibraceX2, kalibraceY2);  //LS
  vybarviPolicko(RED, kalibraceX3, kalibraceY3);  //PH
  vybarviPolicko(RED, kalibraceX4, kalibraceY4);  //PS


  //Serial.print("Kalibrace dotyku-Vysledek=");
  //Serial.println(vysledek);
  while (1) {
    kZahozeni = dotykRychlejsi();
    if (kZahozeni) {
      if (calcX > 0 && calcY > 0 && calcX < 90 && calcY < 50) {
        vybarviPolicko(GREEN, kalibraceX1, kalibraceY1);
        dotknulLH = true;
      }
      if (calcX < 90 && calcY > 430) {
        vybarviPolicko(GREEN, kalibraceX2, kalibraceY2);
        dotknulLS = true;
      }
      if (calcX > 550 && calcY < 50) {
        vybarviPolicko(GREEN, kalibraceX3, kalibraceY3);
        dotknulPH = true;
      }
      if (calcX > 550 && calcY > 430) {
        vybarviPolicko(GREEN, kalibraceX4, kalibraceY4);
        dotknulPS = true;
      } else if (dotknulLH == true && dotknulLS == true && dotknulPH == true && dotknulPS == true) {  //schvalne jsem napsal jednoduse
        zabzuc(1, 50);
        vybarviPolicko(GREEN, kalibraceX, kalibraceY);
        delay(500);
        GUIuvodniMenu();
      }
    }
  }
}
/*
void GUImereniH() { 
  
  predeslyObr = 5;
  prepnutiObrazku(5);
  while (1) {
    kZahozeni = dotykRychlejsi();
    CANvypisovacismycka(ZZ_INF2);
    cislo = rxBuf[0];
    //if(rxId == ZZ_INF2){cislo = int(rxBuf[0]);}
    vypisCislice(cislo);
    if (kZahozeni) {
    if (calcX > 530){
        if (calcY > 70 && calcY < 120) {GUIuvodniMenu();} 
        else if (calcY > 230 && calcY < 280) {GUIgraf();}
      }
    }
  }
}*/

void prepnutiObrazku(short unsigned int volba) {

  posliZacatek();
  posli1Byte(prikazObraz);
  posli1Byte(volba);
  posliKonec();
  //calcX = 0; calcY = 0;
}

int dotykRychlejsi() {  //0 ... ticho, 1 ... uspech, 2 ... spatna zprava, 3 ... chybny vypocet, 4 ... spatne nactena data
  //delay(10);
  Serial.print(calcX);
  Serial.print(", ");
  Serial.println(calcY);
  //Serial.print("");

  calcX = 0;
  calcY = 0;
  byte prevzatyByte0 = 0x00;
  unsigned short int osetreniDvojitehoZacatku = 0;
  //byte prevzatyByte1 = 0x00;
  //byte poziceX[2]={0x00,0x00};
  //byte poziceY[2]={0x00,0x00};
  byte buffer[20];
  for (int i = 0; i < 20; i++) { buffer[i] = 0xFF; }
  //calcX a calcY

  for (int i = 0; i < 20; i++) {  //cteci smycka
    prevzatyByte0 = kom.read();
    if (prevzatyByte0 == 0xFF) { continue; }
    if (prevzatyByte0 == 0x3C) {
      buffer[i] = prevzatyByte0;
      break;
    } else {
      buffer[i] = prevzatyByte0;
    }
  }

  //if((buffer[i+1] == 0x72) || (buffer[i+1] == 0x73))
  //Serial.println("=============");
  /*
  for (int i = 0; i < 20; i++) {  //vypisovaci smycka
    if (buffer[i] == 0xFF) { continue; }
    //else if(buffer[i] == 0x3C){break;}
    else {
      Serial.println(buffer[i], HEX);
    }
  }
  */
  //Serial.println("=============");


  for (int i = 0; i < 20; i++) {
    if (buffer[i] == 0xAA) { osetreniDvojitehoZacatku += 1; }
  }  //osetreniDvojitehoZacatku

  if (osetreniDvojitehoZacatku > 1) {
    //Serial.println("Displej blbne.");
    return 2;
  } else if (osetreniDvojitehoZacatku == 0) { /*Serial.println("Je ticho.");*/
    calcX = 0;
    calcY = 0;
    return 0;
  }

  for (int i = 0; i < 20; i++) {  //vypocetni smycka
    if (buffer[i] == 0xAA) {
      if ((buffer[i + 1] == 0x72) || (buffer[i + 1] == 0x73)) {
        //Serial.print("Souradnice surove: ");
        //Serial.print(buffer[i + 2]);
        //Serial.print(", ");
        //Serial.print(buffer[i + 3]);
        //Serial.print(", ");
        //Serial.print(buffer[i + 4]);
        //Serial.print(", ");
        //Serial.println(buffer[i + 5]);
        if ((buffer[i + 2] > 2) || (buffer[i + 4] > 3)) {
          //Serial.println("Spatne nactena data");
          return 4;
        }
        calcX = 16 * 16 * buffer[i + 2] + buffer[i + 3];
        calcY = 16 * 16 * buffer[i + 4] + buffer[i + 5];
        //Serial.print("Souradnice: ");
        //Serial.print(calcX);
        //Serial.print(", ");
        //Serial.println(calcY);
        if ((calcX > 640) || (calcY > 480)) {
          //Serial.println("Chybny vypocet");
          return 3;
        }
        //Serial.print("Souradnice zpracovane: ");
        //Serial.print(calcX);
        //Serial.print(", ");
        //Serial.println(calcY);
        //Serial.println("=============");
        return 1;  //uspech
      }
    }
  }
}

void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[240]) {

  int odsazeni = 200;
  byte pomocY[2] = { 0x00, 0x96 };
  byte pomocKrok[2] = { 0x00, krok };

  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart);
  posli1Byte(krok);
  posli2Byte(osaX_YO);
  for (int i = 0; i < 120; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();

  byte Xstart2[2] = { Xstart[0], Xstart[1] + 240 };
  ////////////////////////////
  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart2);
  posli1Byte(krok);

  if (poleHodnot[120] < 255) {
    posli1Byte(0x00);
    posli1Byte(poleHodnot[120]);
  } else {
    posli1Byte(0x01);
    poleHodnot[120] -= 255;
    posli1Byte(poleHodnot[120]);
    poleHodnot[120] += 255;
  }


  //posli2Byte(osaX_YO);
  for (int i = 120; i < 240; i++) {
    poleHodnot[i] += 0;
    //if(poleHodnot[i] > 400){poleHodnot[i] = 400;}
    if (poleHodnot[i] < 255) {
      posli1Byte(0x00);
      posli1Byte(poleHodnot[i]);
    } else {
      posli1Byte(0x01);
      poleHodnot[i] -= 255;
      posli1Byte(poleHodnot[i]);
      poleHodnot[i] += 255;
    }  //nesmi prekrocit max hodnotu zobrayitelnou na grafu
  }
  posliKonec();
}

void nastavBarvu(short unsigned int volba) {
  /*
 volba = 1 -> CERNA/BILA
 volba = 2 -> CERVENA/BILA
 volba = 3 -> ZELENA/BILA
 */

  posliZacatek();

  switch (volba) {
    case 1:  //mezera
      posli1Byte(0x40);
      posli2Byte(BLACK);
      posli2Byte(WHITE);
      break;
    case 2:  //mezera
      posli1Byte(0x40);
      posli2Byte(RED);
      posli2Byte(WHITE);
      break;
    case 3:  //mezera
      posli1Byte(0x40);
      posli2Byte(GREEN);
      posli2Byte(WHITE);
      break;
    default:
      digitalWrite(A1, HIGH);
      break;
  }

  posliKonec();
}

void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2], int volba) {
  posliZacatek();
  posli1Byte(0x56);
  posli2Byte(Xstart);
  posli2Byte(Ystart);
  posli2Byte(Xkonec);
  posli2Byte(Ykonec);
  posliKonec();

  if (volba == 1) {  //tlustsi osa Y
    Xstart[1] += 1;
    Xkonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Xstart[1] -= 1;
    Xkonec[1] -= 1;
  }

  if (volba == 2) {  //tlustsi osa X
    Ystart[1] += 1;
    Ykonec[1] += 1;
    posliZacatek();
    posli1Byte(0x56);
    posli2Byte(Xstart);
    posli2Byte(Ystart);
    posli2Byte(Xkonec);
    posli2Byte(Ykonec);
    posliKonec();
    Ystart[1] -= 1;
    Ykonec[1] -= 1;
  }
}

void mrizka() {
  int volbaX = 0;  //2
  int volbaY = 0;  //1

  //OKRAJ X
  byte okrX_XO[2] = { 0x00, 0x00 };
  byte okrX_YO[2] = { 0x00, 0x00 };  //odsazeni 400 pix
  byte okrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte okrX_YE[2] = { okrX_YO[0], okrX_YO[1] };
  //OKRAJ Y
  byte okrY_XO[2] = { 0x00, 0x00 };
  byte okrY_YO[2] = { okrX_YO[0], okrX_YO[1] };
  byte okrY_XE[2] = { okrY_XO[0], okrY_XO[1] };
  byte okrY_YE[2] = { 0x01, 0x90 };

  //MRIZKA X
  byte mrX_XO[2] = { 0x00, 0x00 };  //0 pix offset x
  byte mrX_YO[2] = { 0x01, 0x90 };  //odsazeni 400 pix
  byte mrX_XE[2] = { 0x01, 0xE0 };  //480 pix na sirku
  byte mrX_YE[2] = { mrX_YO[0], mrX_YO[1] };
  //MRIZKA Y
  byte mrY_XO[2] = { 0x00, 0x00 };  //200 pix na sirku, veprostred osy x
  byte mrY_YO[2] = { mrX_YO[0], mrX_YO[1] };
  byte mrY_XE[2] = { mrY_XO[0], mrY_XO[1] };
  byte mrY_YE[2] = { 0x00, 0x00 };  //400 pix na vysku

  short unsigned int odsazeniX = 0;
  short unsigned int odsazeniY = 0;

  nastavBarvu(1);
  nakresliUsecku(okrY_XO, okrY_YO, okrY_XE, okrY_YE, 1);
  nakresliUsecku(okrX_XO, okrX_YO, okrX_XE, okrX_YE, 2);

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniX += 60;
    if (odsazeniX < 255) {
      mrY_XO[0] = 0x00;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
    } else {
      odsazeniX -= 255;
      mrY_XO[0] = 0x01;
      mrY_XO[1] = 60 * i;
      mrY_XE[0] = mrY_XO[0];
      mrY_XE[1] = mrY_XO[1];
      odsazeniX += 255;
      if (i == 8) {
        nastavBarvu(1);
        volbaY = 1;
      }
    }
    nakresliUsecku(mrY_XO, mrY_YO, mrY_XE, mrY_YE, volbaY);
  }

  nastavBarvu(3);

  for (int i = 1; i <= 8; i++) {
    if (i == 8) { nastavBarvu(1); }
    odsazeniY += 50;
    //Serial.print("Y: ");
    //Serial.print(odsazeniY);
    if (odsazeniY < 255) {
      mrX_YO[0] = 0x00;
      mrX_YO[1] = 50 * i;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    } else {
      odsazeniY -= 255;
      mrX_YO[0] = 0x01;
      mrX_YO[1] = odsazeniY;
      mrX_YE[0] = mrX_YO[0];
      mrX_YE[1] = mrX_YO[1];
      odsazeniY += 255;
      nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
    }
  }
  //mrX_YE[0] = mrX_YO[0]; mrX_YE[1] = mrX_YO[1];
  //nakresliUsecku(mrX_XO, mrX_YO, mrX_XE, mrX_YE, volbaX);
  nastavBarvu(3);
}


void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}

void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}

void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}

void posliPrevedeneCislo(unsigned int cisloX) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cisloX, bufferProCislo, 10);
  if ((cisloX < 100) && (cisloX >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cisloX < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}

void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}

void vypisCislice(unsigned int cisloX) {  //3mistny cislo


  byte poziceXNum[] = { 0x01, 0xA9 };
  byte poziceYNum[] = { 0x01, 0xB0 };
  byte zluta[] = { 0xFC, 0x00 };
  byte modra[] = { 0x00, 0x1F };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(poziceXNum);
  posli2Byte(poziceYNum);
  posli1Byte(0x01);  //lib id
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(BLACK);
  posli2Byte(WHITE);
  posli1Byte(0x00);
  posliPrevedeneCislo(cisloX);
  posliKonec();
}
