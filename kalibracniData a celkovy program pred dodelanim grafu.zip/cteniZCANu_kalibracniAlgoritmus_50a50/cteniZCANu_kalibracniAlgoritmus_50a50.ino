#include <mcp_can.h>
#include <SPI.h>

#include <SD.h>
File dataFile;
const int chipSelectSD = 6;
//bool SD_OK = false;

/*=================================================================*/
long unsigned int rxId;
unsigned char len = 0;
byte rxBuf[8];
//char msgString[128];

short unsigned int pomocProm = 0;
const byte dovolenaTolerance = 0x05;
byte PWMmax = 0;
byte PWMmin = 0;
//short unsigned int pocetKroku1 = 0;
short unsigned int pocetKroku2 = 0;

#define CAN0_INT 2
MCP_CAN CAN0(10);

//zkouska posilani zpravy
byte testovaciZprava0[8] = { 0x80, 0x00, 0b00000111, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
byte CANTxOK = 0xFF;

unsigned long const int ZZ_CTRL = 0x15F773F5;
unsigned long const int ZZ_SET = 0x15F774F5;
unsigned long const int ZZ_INF1 = 0x15F771F5;  //krokac
unsigned long const int ZZ_INF2 = 0x15F772F5;  //pwm

//byte CANTxOK = 0xFF;
//byte data[8] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07};
/*
  byte sndStat = CAN0.sendMsgBuf(0x100, 0, 8, data);
  if(sndStat == CAN_OK){
    Serial.println("Message Sent Successfully!");
  } else {
    Serial.println("Error Sending Message...");
  }
*/

void SDpocatecniProcedura();

void CANpocatecniProcedura();
void CANmotor(bool volba, int pocetKroku);  //0 ... doleva, 1 ... doprava
void CANvypisovacismycka(long unsigned int rxIdX);

void setup() {
  Serial.begin(115200);

  Serial.println("========================================================================");
  SDpocatecniProcedura();
  CANpocatecniProcedura();
}

void loop() {}

void CANvypisovacismycka(long unsigned int rxIdX) {
  while (1) {  //vzpisovaci smycka
    if (!digitalRead(CAN0_INT)) {
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == rxIdX) {
        //sprintf(msgString, "Standard ID: 0x%.3lX       DLC: %1d  Data:", rxId, len);  //z ukazky v knihovne modfikovane pro sobni ucely
        //Serial.print(msgString);
        Serial.print("CAN ID:");Serial.print(rxId,HEX);Serial.print(" Data: ");
        for (byte i = 0; i < len; i++) {
          //sprintf(msgString, " 0x%.2X", rxBuf[i]);
          Serial.print(rxBuf[i],HEX);
          Serial.print(" ");
        }
        Serial.println();
        break;
      }
    }
  }
}

void SDpocatecniProcedura() {
  
  if(SD.begin(chipSelectSD)){Serial.println("SD: karta je OK.");}
  else{Serial.println("SD: karta neni OK.");}

  dataFile = SD.open("KLBR.CSV");
  if(dataFile){Serial.println("SD: soubor je OK.");dataFile.close();}
  else{Serial.println("SD: soubor neni OK.");}
  
  /*
  if (SD.exists("KLBR.CSV")) {
    //dataFile.close();
    Serial.println("SD: KLBR.CSV nalezena.");
    //SD_OK = true;
  } else {
    Serial.println("SD: KLBR.CSV nenalezena.");
  }
  */

}

void CANmotor(bool volba, int pocetKroku) {  //0 ... doleva, 1 ... doprava
  byte motor[2] = { 0x00, 0x00 };
  //short int tlacitkoKrok = 1;
  while (1) {
    if (!digitalRead(CAN0_INT)) {  //precti si prichozi motorovou zpravu a uloz si posledni stav motoru
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == ZZ_INF1) {
        //Serial.println("CAN: zprava se opravdu prepsala");
        motor[0] = rxBuf[2];  //prepis low byte
        motor[1] = rxBuf[3];  //prepis high byte
        break;
      }
    }
  }  //mam pozici motoru

  if (volba == 0) {  //motor se otaci doleva
    if (motor[0] == 0x00) {
      motor[0] == 0xFF;  //uz tady jedu doleva o 1 krok
      motor[1] -= 0x01;

      motor[0] -= pocetKroku - 1;
    } else {
      motor[0] -= pocetKroku;
    }
  }

  else if (volba == 1) {  //motor se otaci doprava
    if (motor[0] == 0xFF) {
      motor[0] == 0x00;
      motor[1] += 0x01;  //uz tady jedu doprava o 1 krok

      motor[0] += pocetKroku - 1;
    } else {
      motor[0] += pocetKroku;
    }
  }

  testovaciZprava0[0] = motor[0];
  testovaciZprava0[1] = motor[1];

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);  //posli zpravu pro uklidneni motoru a povoleni mereni PWM

  /*
  if (CANTxOK == CAN_OK) {
    Serial.println("CAN: motor zprava uspesne poslana");
  } else {
    Serial.println("CAN: motor zprava nedorazila");
  }*/
}

void CANpocatecniProcedura() {

  if (CAN0.begin(MCP_ANY, CAN_500KBPS, MCP_16MHZ) == CAN_OK)
    Serial.println("CAN: MCP2515 se bavi");
  else
    Serial.println("CAN: MCP2515 se nebavi");

  CAN0.setMode(MCP_NORMAL);

  pinMode(CAN0_INT, INPUT);

  Serial.println("CAN: MCP2515 zkouska posilani a prijmu zprav");

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);
  if (CANTxOK == CAN_OK) {
    Serial.println("CAN: pocatecni zprava uspesne poslana");
  } else {
    Serial.println("CAN: pocatecni zprava nedorazila");
  }


  while (1) {
    if (!digitalRead(CAN0_INT)) {  //precti si prichozi motorovou zpravu a uloz si posledni stav motoru
      CAN0.readMsgBuf(&rxId, &len, rxBuf);
      rxId -= 0x80000000;
      if (rxId == ZZ_INF1) {
        Serial.println("CAN: zprava se opravdu prepsala");
        testovaciZprava0[0] = rxBuf[2];
        testovaciZprava0[1] = rxBuf[3];

        break;
      }
    }
  }

  CANTxOK = CAN0.sendMsgBuf(ZZ_CTRL, 1, 8, testovaciZprava0);  //posli zpravu pro uklidneni motoru a povoleni mereni PWM
  if (CANTxOK == CAN_OK) {
    Serial.println("CAN: prepsana zprava uspesne poslana");
  } else {
    Serial.println("CAN: prepsana zprava nedorazila");
  }
  
  
  Serial.println("TEST 50-50, TESTOVANI VZDALENOSTI MEZI 2 INSTANCEMI 50proc PWM");

  Serial.println("0.smycka");
  //zacni od mensich hodnot
  while(1){
    CANmotor(1, 1);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    //50 procent PWM je zaokrouhlene 123 dec a 0x71 hex
    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] > 0x00 && rxBuf[0] < 0x07)){
      Serial.println("NULA USPECH");
      break;
    }


  } 

  Serial.println("1.smycka");
  while (1) {  //toc jemne motorem doprava, dokud nenajdes stred
    
    CANmotor(1, 1);
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    //50 procent PWM je zaokrouhlene 123 dec a 0x71 hex
    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] >= (0x71 - dovolenaTolerance) && rxBuf[0] <= (0x71 + dovolenaTolerance))) {
      Serial.println("STRED NALEZEN");
      break;
    }
  }

  Serial.println("2.smycka");
  //vzdal se od stredu
  while(1){
    CANmotor(1, 1);
    pocetKroku2 += 1;
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    //50 procent PWM je zaokrouhlene 123 dec a 0x71 hex
    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] == 0x90)){
      Serial.println("POSUNUTI USPESNE");
      break;
    }


  } 

  Serial.println("3.smycka");
  while (1) {  //toc jemne motorem doprava, dokud nenajdes stred podruhe
    
    CANmotor(1, 1);
    pocetKroku2 += 1;
    CAN0.readMsgBuf(&rxId, &len, rxBuf);
    CANvypisovacismycka(ZZ_INF2);
    //50 procent PWM je zaokrouhlene 123 dec a 0x71 hex
    if (rxId == ZZ_INF2 && rxBuf[5] == 0 && (rxBuf[0] >= (0x71 - dovolenaTolerance) && rxBuf[0] <= (0x71 + dovolenaTolerance))) {
      Serial.println("STRED NALEZEN PODRUHE");
      break;
    }
  }

  dataFile = SD.open("KLBR.CSV", FILE_WRITE);
  if (dataFile) {  
      dataFile.println("===================");    
      dataFile.println("2.KALIBRACNI TEST 50-50");
      dataFile.print("PWM VZDALENOST MEZI BODY 50PROC PWM;");
      dataFile.println(pocetKroku2);
      
      dataFile.close();
      Serial.println("SD: Uspesny zapis do souboru po hotove kalibraci.");
  }
 
  else {Serial.println("SD: Po selhani testu SD karty nemuzu i po hotove kalibraci psat do SD karty.");}

  while(1){}//a skonci
}
