
#include <mcp_can.h>
#include <SPI.h>
#include <SoftwareSerial.h>
#include <SD.h>

const int chipSelectSD = 6;
File dataFile;
unsigned long int cycleCount = 0;
#define rx 3
#define tx 4

//int decMess = 0;
//short unsigned int cursor = 0;
//int pozX[2] = {0,0};
//int pozY[2] = {0,0};
int calcX = 0;
int calcY = 0;
//int *pointerCalcX = &calcX;
//int *pointerCalcY = &calcY;

long unsigned int rxId;
unsigned char len = 0;
unsigned char rxBuf[8];
char msgString[128];

int prectenaHodnota = 0;
short int popelnice = 0;
short int cekamCekam = 0;

const byte zacatek = 0xAA;
const byte konec[4] = { 0xCC, 0x33, 0xC3, 0x3C };
const byte textTrimr[6] = { 0x54, 0x52, 0x49, 0x4D, 0x52, 0x3A };
//text pro SAVE, WRITE, ERASE
const byte textSAVE[4] = { 0x53, 0x41, 0x56, 0x45 };
const byte textWRITE[5] = { 0x57, 0x52, 0x49, 0x54, 0x45 };
const byte textERASE[5] = { 0x45, 0x52, 0x41, 0x53, 0x45 };

SoftwareSerial kom(rx, tx);
MCP_CAN CAN0(10);

void printRxCAN();
void clearObr();
void posli1Byte(byte b1);
void posli2Byte(byte b2[]);
void posliZacatek();
void posliKonec();
void posliSekvenci(byte zprava[]);
void posliPrevedeneCislo(unsigned int cislo);

int debugDotyk(bool volba);  //FALSE ... 0X72, TRUE ... OX73
//int dotykSouradnice(bool volba);//FALSE ... 0X72, TRUE ... OX73
void charCislaNaHexZpravu(char znak);
void vypisCislice(unsigned int cislo);
void kalibraceDotyku();
/////////////////////////////////////////////////////////////////////////
/*
ukazka vykresleni cernzch os X a Y
popisku os X a Y
vykresleni cervene sinusovky y = 50 * (sin(x) + 1 )
a zelene ,,stredove osy"

soucasti ukazky je zapsani do SD karty unikatniho ID zaznamu hodnot
a vypis vsech pouzitych hodnot ve formatu .CSV  
*/

//funkce a hodnoty pro kresbu a praci s grafem
//
unsigned short int recordID = 0;
const byte BLACK[2] = { 0x00, 0x00 };
const byte WHITE[2] = { 0xFF, 0xFF };
const byte GREEN[2] = { 0x07, 0xE0 };
const byte RED[2] = { 0xF8, 0x00 };

//OSA X
const byte osaX_XO[2] = { 0x00, 0x96 };  //50 pix offset x
const byte osaX_YO[2] = { 0x01, 0x00 };
const byte osaX_XE[2] = { 0x01, 0xFE };  //360 pix na sirku,2 pix = 1 uhel
const byte osaX_YE[2] = { 0x01, 0x00 };
//OSA Y
const byte osaY_XO[2] = { 0x01, 0x4A };
const byte osaY_YO[2] = { 0x01, 0x00 };
const byte osaY_XE[2] = { 0x01, 0x4A };
const byte osaY_YE[2] = { 0x00, 0x9B };  //veprostred osy X, 100 pix na sirku
//"stredova" osa
const byte stred_XO[2] = { 0x00, 0x96 };
const byte stred_YO[2] = { 0x00, 0xCD };  //50 pix na vysku
const byte stred_XE[2] = { 0x01, 0xFE };
const byte stred_YE[2] = { 0x00, 0xCD };  //50 pix na vysku

short int Yhodnoty[180];  // y = 50 * (sin(x) + 1 )
//const float prevodRad = 0.017;
/*
volba = 1 -> CERNA/BILA
volba = 2 -> CERVENA/BILA
volba = 3 -> ZELENA/BILA
*/
void nastavBarvu(short unsigned int volba);
void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2]);
void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[180]);
/////////////////////////////////////////////////////////////////////////


void setup() {
  Serial.begin(115200);
  kom.begin(9600);
  delay(2000);
  //f(CAN0.begin(MCP_ANY, CAN_500KBPS, MCP_16MHZ) == CAN_OK)
  //  Serial.println("MCP2515 Initialized Successfully!");
  //else
  //   Serial.println("Error Initializing MCP2515...");

  //CAN0.setMode(MCP_NORMAL);                     // Set operation mode to normal so the MCP2515 sends acks to received data.

  //pinMode(CAN0_INT, INPUT);                            // Configuring pin for /INT input

  // nastaveni LEDek
  pinMode(A1, OUTPUT);
  pinMode(A2, OUTPUT);
  pinMode(A3, OUTPUT);
  pinMode(A4, OUTPUT);
  pinMode(A5, OUTPUT);

  //nahodne ID zaznamu
  randomSeed(analogRead(A0));
  recordID = random(1000);

  //////////////////////////////////////////////////////////
  Serial.print("SD: inicializace");
  if (!SD.begin(chipSelectSD)) {
    Serial.println(" neuspesna");
  } else {
    Serial.println(" uspesna");
  }
  dataFile = SD.open("data.csv");
  if (dataFile == 1) {
    Serial.println("SD: nasel se .csv soubor");
  } else {
    Serial.println("SD: nenasel se .csv soubor");
  }
  dataFile.close();

  Serial.println("BOOTOVANI HOTOVO");
  Serial.println("=========================================================");
  //kalibraceDotyku();
  digitalWrite(A4, HIGH);
  //delay(100);
  //osa X a osa Y, stred. osa

  nastavBarvu(1);
  //delay(100);
  clearObr();
  //delay(100);
  nakresliUsecku(osaX_XO, osaX_YO, osaX_XE, osaX_YE);
  nakresliUsecku(osaY_XO, osaY_YO, osaY_XE, osaY_YE);
  nastavBarvu(3);
  nakresliUsecku(stred_XO, stred_YO, stred_XE, stred_YE);
  digitalWrite(A3, HIGH);
  nastavBarvu(2);
  for (int i = -90; i < 90; i++) {
    Yhodnoty[i + 90] = 50 * (sin(i) + 1);
  }
  Serial.print("HODNOTY: ");
  for (int i = 0; i < 180; i++) {
    Serial.print(Yhodnoty[i]);
    Serial.print(", ");
  }
  Serial.println();
  nakresliFunkci(stred_XO, 0x03, Yhodnoty);
  digitalWrite(A2, HIGH);

  dataFile = SD.open("data.csv", FILE_WRITE);
    if (dataFile == 1) {
    //dataFile.open();
    dataFile.println("===============================");
    dataFile.print("ZAZNAM CISLO: ");
    dataFile.println(recordID);
    dataFile.println("HODNOTA X [uhel];HODNOTA Y [ - ]");
   for (int i = 0; i < 180; i++) {
     dataFile.print(i);
     dataFile.print(";");
     dataFile.println(Yhodnoty[i]);
    }
   dataFile.println("===============================");
    dataFile.close();
    Serial.println("SD:USPECH");
  }
  else{Serial.println("SD:NEUSPECH");}

  
  digitalWrite(A1, HIGH);


}



/*
   if (dataFile == 1) {
          dataFile.print("CYKLUS: ");
          dataFile.println(cycleCount);
          dataFile.println("ZMACKNUTO: WRITE");
          dataFile.print("TRIMR: ");
          dataFile.println(prectenaHodnota);
          dataFile.close();
          Serial.println("SD: WRITE OK, WRITE");
          }
*/

void loop() {
}

void nakresliFunkci(byte Xstart[2], byte krok, short int poleHodnot[180]) {
  byte pomocY[2] = { 0x00, 0x96 };
  byte pomocKrok[2] = { 0x00, krok };
  posliZacatek();
  posli1Byte(0x76);
  posli2Byte(Xstart);
  posli1Byte(krok);
  posli2Byte(osaX_YO);
  for (int i = 0; i < 180; i++) {
    posli1Byte(0x00);
    posli1Byte(poleHodnot[i] + 150);
  }
  posliKonec();
}

void kalibraceDotyku() {
  posliZacatek();
  posli1Byte(0xE4);
  posli1Byte(0x55);
  posliZacatek();
  posli1Byte(0x5A);
  posli1Byte(0xA5);
  posliKonec();
}

void nastavBarvu(short unsigned int volba) {
  /*
 volba = 1 -> CERNA/BILA
 volba = 2 -> CERVENA/BILA
 volba = 3 -> ZELENA/BILA
 */

  posliZacatek();

  switch (volba) {
    case 1:  //mezera
      posli1Byte(0x40);
      posli2Byte(BLACK);
      posli2Byte(WHITE);
      break;
    case 2:  //mezera
      posli1Byte(0x40);
      posli2Byte(RED);
      posli2Byte(WHITE);
      break;
    case 3:  //mezera
      posli1Byte(0x40);
      posli2Byte(GREEN);
      posli2Byte(WHITE);
      break;
    default:
      digitalWrite(A1, HIGH);
      break;
  }

  posliKonec();
}

void nakresliUsecku(byte Xstart[2], byte Ystart[2], byte Xkonec[2], byte Ykonec[2]) {
  posliZacatek();
  posli1Byte(0x56);
  posli2Byte(Xstart);
  posli2Byte(Ystart);
  posli2Byte(Xkonec);
  posli2Byte(Ykonec);
  posliKonec();
}






/*void printRxCAN() {
  if(!digitalRead(CAN0_INT))                         // If CAN0_INT pin is low, read receive buffer
  {
    CAN0.readMsgBuf(&rxId, &len, rxBuf);      // Read data: len = data length, buf = data byte(s)
    if(rxId == 0x95F772F5){*/
//rxId == 0x98FECAF5
/*0x95F772F5*/
/*0x98FECAF5*/
/*0x95F771F5*/
/*prectenaHodnota = int(rxBuf[0]);
    sprintf(msgString, "Standard ID: 0x%.3lX       DLC: %1d  Data:", rxId, len);
    Serial.print(msgString);
    for(byte i = 0; i<len; i++){
        sprintf(msgString, " 0x%.2X", rxBuf[i]);
        Serial.print(msgString);
    }
    Serial.println();
    }
  }
  //delay(500);
}*/

void clearObr() {
  byte clr = 0x52;
  posliZacatek();
  posli1Byte(clr);
  posliKonec();
}

void posliKonec() {
  for (int i = 0; i < sizeof(konec); i++) { kom.write(konec[i]); }
}
void posliSekvenci(byte zprava[], int delka) {
  for (int i = 0; i < delka; i++) { posli1Byte(zprava[i]); }
}
void posliPrevedeneCislo(unsigned int cislo) {
  char bufferProCislo[3] = { '0', '0', '0' };
  itoa(cislo, bufferProCislo, 10);
  if ((cislo < 100) && (cislo >= 10)) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
  } else if (cislo < 10) {
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu('0');
    charCislaNaHexZpravu(bufferProCislo[0]);
  } else {
    charCislaNaHexZpravu(bufferProCislo[0]);
    charCislaNaHexZpravu(bufferProCislo[1]);
    charCislaNaHexZpravu(bufferProCislo[2]);
  }
}
void posliZacatek() {
  kom.write(zacatek);
}
void posli1Byte(byte b1) {
  kom.write(b1);
}
void posli2Byte(byte b2[]) {
  posli1Byte(b2[0]);
  posli1Byte(b2[1]);
}

void charCislaNaHexZpravu(char znak) {
  switch (znak) {
    case ' ':  //mezera
      posli1Byte(0x20);
      break;
    case '0':            //mezera
      posli1Byte(0x30);  //muyu k tomuhle pricitat offset, ALE tohle je citelnejsi
      break;
    case '1':  //mezera
      posli1Byte(0x31);
      break;
    case '2':  //mezera
      posli1Byte(0x32);
      break;
    case '3':  //mezera
      posli1Byte(0x33);
      break;
    case '4':  //mezera
      posli1Byte(0x34);
      break;
    case '5':  //mezera
      posli1Byte(0x35);
      break;
    case '6':  //mezera
      posli1Byte(0x36);
      break;
    case '7':  //mezera
      posli1Byte(0x37);
      break;
    case '8':  //mezera
      posli1Byte(0x38);
      break;
    case '9':  //mezera
      posli1Byte(0x39);
      break;
    default:
      delay(1);
  }
}

void vypisCislice(unsigned int cislo) {  //3mistny cislo


  byte poziceXNum[] = { 0x00, 0xFF };
  byte poziceYNum[] = { 0x00, 0xFF };
  byte zluta[] = { 0xFC, 0x00 };
  byte modra[] = { 0x00, 0x1F };


  ////////////////////////////////////////////////////////////////////////////////////////
  posliZacatek();
  posli1Byte(0x98);  //ID
  posli2Byte(poziceXNum);
  posli2Byte(poziceYNum);
  posli1Byte(0x00);  //00
  posli1Byte(0xC1);  //styl zobrazeni
  posli1Byte(0x05);  //ID KNIHOVNY
  posli2Byte(zluta);
  posli2Byte(modra);
  posli1Byte(0x00);
  posliPrevedeneCislo(cislo);

  posliKonec();
}

int debugDotyk(bool volba) {  //FALSE ... 0X72, TRUE ... OX73
  int decMess = 0;
  bool spravnyStart = false;
  short unsigned int cursor = 1;
  int pozX[2] = { 0, 0 };
  int pozY[2] = { 0, 0 };

  Serial.print("RS232: ");
  while (true) {
    decMess = int(kom.read());
    switch (decMess) {
      case 170:
        //Serial.print("xAA ");
        spravnyStart = true;
        cursor += 1;
        break;
      case 204:
        calcX = pozX[0] * 16 * 16 + pozX[1];
        calcY = pozY[0] * 16 * 16 + pozY[1];
        //*pointerCalcX = funcCalcX;
        //*pointerCalcY = funcCalcY;
        /*
        if((calcX < 305)&&(calcY < 230)){DebugLED(10);}
        else if((calcX > 305)&&(calcY < 230)){DebugLED(9);}
        else if((calcX < 305)&&(calcY > 230)){DebugLED(11);}
        else if((calcX > 305)&&(calcY > 230)){DebugLED(12);}

        Serial.print("()()zaznam pozice X= ");Serial.print(pozX[0]);Serial.print(" ");Serial.print(pozX[1]);//zaznam x
        Serial.print(" zaznam pozice Y= ");Serial.print(pozY[0]);Serial.print(" ");Serial.print(pozY[1]);//zaznam y
        Serial.print(" pozice X= ");Serial.print(calcX);Serial.print(" pix, ");//kalkulace x
        Serial.print("pozice Y= ");Serial.print(calcY);Serial.print(" pix()() ");//kalkulace y
        */
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.print("xCC ");
        cursor += 1;
        break;
      case 60:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          return 2;
        }
        Serial.println("x3C");

        cursor = 1;
        decMess = -1;
        cekamCekam = 0;
        //DebugLED(3);
        return 1;  //vse ok
        break;
      case 195:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print("xC3 ");
        cursor += 1;
        break;
      case 51:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print("x33 ");
        cursor += 1;
        break;
      case 114:
        if ((volba == true) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }  //chci 0x73
        Serial.print("xAA x72 ");
        cursor += 1;
        //pozX = int(kom.read())*16*16 + int(kom.read())*16;
        //pozY = int(kom.read())*16*16 + int(kom.read())*16;
        //Serial.print("pozice X = ");Serial.print(pozX);
        //Serial.print(", pozice Y = ");Serial.print(pozY);Serial.print(" ");
        break;
      case 115:
        if ((volba == false) || (spravnyStart == false)) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }  //chci 0x72
        Serial.print("xAA x73 ");
        cursor += 1;
        break;
      case -1:  //SKIP
        cekamCekam += 1;
        if (cekamCekam == 10) {
          Serial.println("NULL");
          cekamCekam = 0;
          //DebugLED(5);
          return 3;
        }
        break;
      default:
        if (spravnyStart == false) {
          Serial.println("WRONG");
          cursor = 0;
          cekamCekam = 0;
          //DebugLED(4);
          return 2;
        }
        Serial.print(decMess);
        if (cursor == 3) { pozX[0] = decMess; }
        if (cursor == 4) { pozX[1] = decMess; }
        if (cursor == 5) { pozY[0] = decMess; }
        if (cursor == 6) { pozY[1] = decMess; }
        cursor += 1;
        Serial.print(" ");
        break;
    }
  }
}
